"use strict";
cc._RFpush(module, '6dc7fU5gx9E6Y+XDk+09FHs', 'Pass');
// Scripts/Map/Pass.js

var MapNode = require("MapNode");
cc.Class({
    "extends": cc.Component,

    properties: {
        mapNode: cc.Prefab,
        pass: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.passes = [[[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]], [[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]], [[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]]];
        this.nodes = [];
    },

    //手动创建tileMap背景层
    initTitleByPass: function initTitleByPass(pass, node) {
        var passInfo = this.passes[pass];
        var len = passInfo.length;
        for (var i = 0; i < len; i++) {
            var leng = passInfo[i].length;
            for (var j = 0; j < leng; j++) {
                var mapNode = cc.instantiate(this.mapNode);
                mapNode.parent = node;
                var nodeCode = mapNode.getComponent("MapNode");
                nodeCode.setStyle(passInfo[j][i]);
                nodeCode.setPostion(i, j);
                // this.nodes[i][j] = mapNode ;
            }
        }
    }
});

cc._RFpop();