"use strict";
cc._RFpush(module, 'e4886Ka3ylI4rww6fxgyY4n', 'BlockLayer');
// Scripts/Map/BlockLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        blockTile: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {},

    initPass: function initPass(currentPass) {
        if (!this.passNode) {
            this.blockTile = cc.instantiate(this.blockTile);
            this.blockTile.parent = this.node;
        }
        var blockTileCode = this.blockTile.getComponent("BlockTile");
        blockTileCode.initBlockByPass(currentPass, this.node);
    }
});

cc._RFpop();