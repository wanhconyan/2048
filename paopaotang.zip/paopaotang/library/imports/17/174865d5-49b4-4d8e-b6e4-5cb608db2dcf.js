cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    startGame: function startGame() {
        cc.director.loadScene("GameView");
    },

    openHelpPanel: function openHelpPanel() {
        this.gameControl.showHelpPanel();
    }

});