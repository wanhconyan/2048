"use strict";
cc._RFpush(module, '4c0f7wKW/tOMrOr9LHYJ2vA', 'SnakeHead');
// Scripts/Snake/SnakeHead.js

var Base = require("Base");
var Global = require("Global");
cc.Class({
    "extends": Base,

    properties: {},

    onLoad: function onLoad() {
        this.toAngle = 0;
        this.angle = 0;
    },

    moveTo: function moveTo(angle) {
        this.toAngle = angle;
    },

    update: function update(t) {
        if (this.angle != this.toAngle) {
            this.angle += 0.08;
            this.node.rotation = this.angle;
        }
        this.vx = .5 * Math.cos(this.angle);
        this.vy = .5 * Math.sin(this.angle);
        this.node.x += this.vx;
        this.node.y += this.vy;
        console.log(this.node.x, this.node.y);
    }
});

cc._RFpop();