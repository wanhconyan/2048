var SPEED = 4;
var SPEED_UP = 8;
var TURN_SPEED = 0.08;
module["export"] = {
    SPEED: SPEED,
    SPEED_UP: SPEED_UP,
    TURN_SPEED: TURN_SPEED
};