cc.Class({
    'extends': cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.node.on('touchstart', this.onTouchStart, this);
        this.node.on('touchend', this.onTouchEnd, this);
        this.node.on('touchcancel', this.onTouchEnd, this);
    },

    onTouchStart: function onTouchStart() {
        this.node.scaleX = this.node.scaleY = 0.9;
    },

    onTouchEnd: function onTouchEnd() {
        this.node.scaleX = this.node.scaleY = 1;
    }

});