"use strict";
cc._RFpush(module, '6a1d8J9Y7NLopSNzYp/YK57', 'Global');
// Scripts/Module/Global.js

var SPEED = 4;
var SPEED_UP = 8;
var TURN_SPEED = 0.08;
module["export"] = {
    SPEED: SPEED,
    SPEED_UP: SPEED_UP,
    TURN_SPEED: TURN_SPEED
};

cc._RFpop();