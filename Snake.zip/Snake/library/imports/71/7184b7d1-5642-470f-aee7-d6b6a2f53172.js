var Snake = require("Snake");
cc.Class({
    "extends": cc.Component,

    properties: {
        owner: Snake,
        vx: 0,
        vy: 0,
        texture: cc.SpriteFrame,
        speed: 0,
        angle: 0
    },

    //初始化蛇形状
    init: function init(data) {},

    onLoad: function onLoad() {},

    moveTo: function moveTo() {},

    render: function render() {},

    update: function update(t) {
        this.x += this.vx;
        this.y += this.vy;
    }

});