var Global = require("Global");
cc.Class({
    "extends": cc.Component,
    properties: {
        angle: 0.0,
        snakeHead: cc.Prefab,
        canvas: cc.Node

    },

    onLoad: function onLoad() {
        this.head = cc.instantiate(this.snakeHead);
        this.head.parent = this.canvas;
        this.headCode = this.head.getComponent("SnakeHead");
    },

    moveTo: function moveTo(angle) {
        this.headCode.moveTo(angle);
    },

    update: function update(t) {}

});