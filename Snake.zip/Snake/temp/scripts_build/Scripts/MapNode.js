"use strict";
cc._RFpush(module, 'da26cQtr+VBb4jWssImSwBJ', 'MapNode');
// Scripts/MapNode.js

cc.Class({
    "extends": cc.Component,

    properties: {
        defH: 80,
        defW: 160,
        defX: 0,
        defY: 0
    },

    onLoad: function onLoad() {},

    //设置位置
    setPostion: function setPostion(i, j) {
        this.node.x = i * this.defW + this.defX;
        this.node.y = -j * this.defH + this.defY;
    }

});

cc._RFpop();