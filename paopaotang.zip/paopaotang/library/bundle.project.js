require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"AStar":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c84f6IBYJNKfpJgWbiI5JIV', 'AStar');
// Scripts/Astar/AStar.js

var Grid = require("Grid");
cc.Class({
    "extends": cc.Component,

    properties: {
        vistedNum: 0,
        visited: [],
        maxX: 10,
        maxY: 10,
        maps: [],
        close: [],
        open: [],
        around: [[0, -1], [1, 0], [-1, 0], [0, 1]] //四方向
    },

    onLoad: function onLoad() {},

    //查找路径
    findPath: function findPath(start, end) {
        var path = [];
        this.start = start;
        this.end = end;
        this.vistedNum = 0;
        this.visited = [];
        this.start.f = this.start.g = this.start.h = 0;

        return path;
    },

    euclidian: function euclidian(grid) {
        var disX = this.end.x - grid.x;
        var disY = this.end.y - grid.y;
        return disX * disX + disY * disY;
    },

    diagonal: function diagonal(grid) {
        var disX = this.end.x - grid.x;
        var dixY = this.end.y - grid.y;
        if (disX < 0) disX *= -1;
        if (disY < 0) disY *= -1;
        var min = disX < disY ? disX : disY;
        return min * Math.SQRT2 + (disX + disY - 2 * min);
    }

});

cc._RFpop();
},{"Grid":"Grid"}],"BlockLayer":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e4886Ka3ylI4rww6fxgyY4n', 'BlockLayer');
// Scripts/Map/BlockLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        blockTile: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {},

    initPass: function initPass(currentPass) {
        if (!this.passNode) {
            this.blockTile = cc.instantiate(this.blockTile);
            this.blockTile.parent = this.node;
        }
        var blockTileCode = this.blockTile.getComponent("BlockTile");
        blockTileCode.initBlockByPass(currentPass, this.node);
    }
});

cc._RFpop();
},{}],"BlockTile":[function(require,module,exports){
"use strict";
cc._RFpush(module, '3d180bJnpVGIo4d9K+eG7ab', 'BlockTile');
// Scripts/Map/BlockTile.js

cc.Class({
    "extends": cc.Component,

    properties: {
        block: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.blocks = [[[0, 0, 0, 6, 0, 0, 0, 16, 17, 6], [0, 17, 0, 0, 0, 0, 0, 0, 0, 6], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 0, 0, 0, 0, 6, 0, 0, 17, 16], [16, 17, 0, 0, 0, 6, 0, 0, 17, 16], [0, 0, 0, 0, 6, 0, 0, 0, 17, 16], [0, 0, 0, 0, 0, 6, 6, 0, 0, 0], [16, 17, 0, 0, 6, 0, 0, 0, 17, 6], [6, 0, 0, 0, 0, 6, 6, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]], [[0, 0, 0, 6, 0, 0, 0, 16, 17, 6], [0, 17, 0, 0, 0, 0, 0, 0, 0, 6], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 6, 0, 16, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]], [[0, 0, 0, 6, 0, 0, 0, 16, 17, 6], [0, 17, 0, 0, 0, 0, 0, 0, 0, 6], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 6, 0, 16, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]], [[0, 0, 0, 6, 0, 0, 0, 16, 17, 6], [0, 17, 0, 0, 0, 0, 0, 0, 0, 6], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 6, 0, 16, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]], [[0, 0, 0, 6, 0, 0, 0, 16, 17, 6], [0, 17, 0, 0, 0, 0, 0, 0, 0, 6], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 0, 0, 17, 16], [0, 16, 0, 0, 0, 6, 6, 0, 16, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]];
    },

    //手动创建tileMap背景层
    initBlockByPass: function initBlockByPass(pass, node) {
        var blockInfo = this.blocks[pass];
        var len = blockInfo.length;
        for (var i = 0; i < len; i++) {
            var leng = blockInfo[i].length;
            for (var j = 0; j < leng; j++) {
                var style = blockInfo[j][i];
                if (style == 0) {
                    continue;
                }
                var block = cc.instantiate(this.block);
                block.parent = node;
                var nodeCode = block.getComponent("Block");
                nodeCode.setBoxStyle(style);
                nodeCode.setPostion(i, j);
            }
        }
    }
});

cc._RFpop();
},{}],"Block":[function(require,module,exports){
"use strict";
cc._RFpush(module, '49397s7EuVLGrQnl+EPL57B', 'Block');
// Scripts/Map/Block.js

var RewardType = cc.Enum({});
cc.Class({
    "extends": cc.Component,

    properties: {
        rewardType: -1,
        defX: -270,
        defY: 361,
        defW: 60,
        defH: 66
    },

    // use this for initialization
    onLoad: function onLoad() {
        var sprite = this.getComponent(cc.Sprite);
        if (sprite.spriteFrame) {
            this.resize(sprite.spriteFrame.getRect());
        }
        this.animation = this.getComponent(cc.Animation);
        this.animation.on("stop", this.playEffectComplete, this);
    },

    //砖块被炸 通过奖励类型判断是否生成奖励物品，和奖励物品的种类
    boomBlock: function boomBlock(rewardType) {

        if (rewardType != -1) this.gernateReward(rewardType);else this.node.active = false;
    },

    playEffectComplete: function playEffectComplete() {
        this.animation.node.active = false;
    },

    //生成奖励
    gernateReward: function gernateReward(reward) {},

    //播放爆炸特效
    playBombEffect: function playBombEffect() {
        var animation = this.getComponent(cc.Animation);
        animation.active = true;
        cc.loader.loadRes("Map/block/bomb", cc.SpriteAtlas, function (err, atlas) {
            var spriteFrames = atlas.getSpriteFrames();

            var clip = cc.AnimationClip.createWithSpriteFrames(spriteFrames, 12);
            clip.name = 'run';
            clip.wrapMode = cc.WrapMode.Default;
            animation.addClip(clip);
            animation.play('run');
        });
    },

    //吃掉当前格子中的奖励 并销毁对象
    biteReward: function biteReward() {
        this.node.active = false;
    },

    //设置格子样式，并为格子设置格子碰撞体积
    setBoxStyle: function setBoxStyle(style) {
        var self = this;
        var sprite = self.getComponent(cc.Sprite);
        cc.loader.loadRes("Map/block/blockAltas", cc.SpriteAtlas, function (err, atlas) {
            var frame = atlas.getSpriteFrame('box' + style);
            sprite.spriteFrame = frame;
            self.resize(sprite.spriteFrame.getRect());
        });
    },

    //设置节点大小和碰撞体积
    resize: function resize(size) {
        this.node.width = size.width;
        this.node.height = size.height;
        var box = this.getComponent(cc.BoxCollider);
        box.size = size;
    },

    //设置位置
    setPostion: function setPostion(i, j) {
        this.node.x = i * this.defW + this.defX;
        this.node.y = -j * this.defH + this.defY;
    }

});

cc._RFpop();
},{}],"Bomb":[function(require,module,exports){
"use strict";
cc._RFpush(module, '36d8cqGRRFCj64n+RA9ztl9', 'Bomb');
// Scripts/Player/Bomb.js

var BoomEvent = cc.Enum({
    BOOM_ROUND: "boomRound",
    BOOM_OVER: "boomOver"
});
cc.Class({
    "extends": cc.Component,

    properties: {
        attackRound: 1,
        bombEffect: {
            type: cc.Animation,
            "default": null
        },
        bombTime: 4 },

    //爆炸事件
    onLoad: function onLoad() {
        this.types = ["Hero/bomb", "Hero/bomb", "Hero/bomb", "Hero/bomb1", "Hero/bomb1", "Hero/bomb1"];
    },

    //在i,j节点生产一个type类型的炸弹
    initBombWith: function initBombWith(type) {
        var _this = this;

        var self = this;
        var url = this.types[type];
        self.animation = this.getComponent(cc.Animation);
        self.animation.active = true;
        cc.loader.loadRes(url, cc.SpriteAtlas, function (err, atlas) {
            self.heroAtlas = atlas;
            _this.play("bomb");
        });
    },

    //创建以key为截点的动画
    createAnimationClips: function createAnimationClips(key, frameCount) {
        var frame = [];
        for (var i = 1; i <= frameCount; i++) {
            console.log(key);
            var spriteFrame = this.heroAtlas.getSpriteFrame(key + i);
            frame.push(spriteFrame);
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, frameCount);
        clip.name = key;
        clip.wrapMode = cc.WrapMode.Loop;
        this.animation.addClip(clip);
    },

    //播放相应动画
    play: function play(key) {
        if (!this.animation._nameToState[key]) {
            this.createAnimationClips(key, 4);
        }
        this.animation.play(key);
    },

    //爆炸 并通知爆炸范围
    bombThisMine: function bombThisMine() {
        var round;
        this.node.emit(BoomEvent.BOOM_ROUND, {});
    },

    //获取爆炸范围
    getBoomRound: function getBoomRound() {}
});

cc._RFpop();
},{}],"BuildSetting":[function(require,module,exports){
"use strict";
cc._RFpush(module, '7aceaw0jg9CTaNF2K7qrKTJ', 'BuildSetting');
// Scripts/Map/BuildSetting.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"BuildingLayer":[function(require,module,exports){
"use strict";
cc._RFpush(module, '289baKHvkRPzoGERVse+gS4', 'BuildingLayer');
// Scripts/Map/BuildingLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"ButtonScaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'eae60bURspATIXPaDB3USJH', 'ButtonScaler');
// Scripts/Effect/ButtonScaler.js

cc.Class({
    'extends': cc.Component,

    properties: {
        pressedScale: 1,
        transDuration: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.initScale = this.node.scale;
        self.button = self.getComponent(cc.Button);
        self.scaleDownAction = cc.scaleTo(self.transDuration, self.pressedScale);
        self.scaleUpAction = cc.scaleTo(self.transDuration, self.initScale);
        function onTouchDown(event) {
            this.stopAllActions();
            this.runAction(self.scaleDownAction);
        }
        function onTouchUp(event) {
            this.stopAllActions();
            this.runAction(self.scaleUpAction);
        }
        this.node.on('touchstart', onTouchDown, this.node);
        this.node.on('touchend', onTouchUp, this.node);
        this.node.on('touchcancel', onTouchUp, this.node);
    }
});

cc._RFpop();
},{}],"GameControl":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1c8ff8f46dDa7493RRdSun3', 'GameControl');
// Scripts/Control/GameControl.js

var HelpPanel = require('HelpPanel');
var StartGame = require('StartGame');
cc.Class({
    'extends': cc.Component,

    properties: {
        helpPanel: {
            type: HelpPanel,
            'default': null
        },
        startGame: {
            type: StartGame,
            'default': null
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.startGame.gameControl = this;
        this.helpPanel.node.active = false;
        this.startGame.node.active = true;
    },

    showHelpPanel: function showHelpPanel() {
        this.helpPanel.node.active = true;
        this.startGame.node.active = false;
    }
});

cc._RFpop();
},{"HelpPanel":"HelpPanel","StartGame":"StartGame"}],"Grid":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'd039biCL95Bf5MZcES5z88B', 'Grid');
// Scripts/Astar/Grid.js

// const Grid = require("Grid")
cc.Class({
    "extends": cc.Component,

    properties: {
        x: 0,
        y: 0,
        g: 0.0,
        f: 0.0,
        h: 0.0,
        walkAble: cc.Boolean,
        maxRaw: 10,
        maxCol: 9
    },
    // use this for initialization
    onLoad: function onLoad() {},

    //初始化A星格子
    init: function init(x, y, g, f, moveAble) {
        this.x = x;
        this.y = y;
        this.g = g;
        this.f = f;
        this.moveAble = moveAble;
        this.h = g * 10 + f * 10;
    },

    reset: function reset() {
        this.x = 0;
        this.y = 0;
        this.f = 0;
        this.g = 0;
        this.h = 0;
        this.walkAble = false;
    }

});

cc._RFpop();
},{}],"HelpPanel":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ab26frIlxZJV5pjLbDUhLG8', 'HelpPanel');
// Scripts/UI/HelpPanel.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    startGame: function startGame() {
        cc.director.loadScene("GameView");
    }
});

cc._RFpop();
},{}],"InputControl":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1595d3xoqJFgo27/PXUbzlJ', 'InputControl');
// Scripts/Control/InputControl.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        // this.blockNode = cc.instantiate(this.block);
        // this.blockNode.parent = this.node ;
        // this.blockNode.x = -280;
        // this.blockNode.y = -400 ;
    },

    // playEffect:function()
    // {
    //     var blockNode = this.blockNode.getComponent("Block");
    //     blockNode.playBombEffect();
    // }

    //移动玩家
    move: function move(event, direction) {
        console.log(direction);
        this.game.move(direction);
    },

    //放置炸弹
    putBomb: function putBomb() {
        this.game.putBomb();
    }

});

cc._RFpop();
},{}],"MapControl":[function(require,module,exports){
"use strict";
cc._RFpush(module, '94b2aCwo6xFUY1T3YnWFiz+', 'MapControl');
// Scripts/Control/MapControl.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    getMapByLevel: function getMapByLevel(level) {
        var map = [];

        return map;
    }
});

cc._RFpop();
},{}],"MapNode":[function(require,module,exports){
"use strict";
cc._RFpush(module, '0b865uwMctF/Y+Ixw+rkyBe', 'MapNode');
// Scripts/Map/MapNode.js

cc.Class({
    "extends": cc.Component,

    properties: {
        tileMapNode: {
            type: cc.Sprite,
            "default": null
        },
        defX: -270,
        defY: 361,
        defW: 60,
        defH: 60

    },
    onLoad: function onLoad() {},

    //设置位置
    setPostion: function setPostion(i, j) {
        this.node.x = i * this.defW + this.defX;
        this.node.y = -j * this.defH + this.defY;
    },

    //设置样式
    setStyle: function setStyle(style) {
        var sprite = this.getComponent(cc.Sprite);
        cc.loader.loadRes("Map/tile/tileAltas", cc.SpriteAtlas, function (err, atlas) {
            var frame = atlas.getSpriteFrame('node' + style);
            sprite.spriteFrame = frame;
        });
    }

});

cc._RFpop();
},{}],"Map":[function(require,module,exports){
"use strict";
cc._RFpush(module, '0806ce63q5B1LBCeySXpmUf', 'Map');
// Scripts/Map/Map.js

var InputControl = require("InputControl");
cc.Class({
    "extends": cc.Component,

    properties: {
        level: 0,
        inputControl: InputControl
    },

    onLoad: function onLoad() {
        this.titleLayer = this.getComponent("TileLayer");
        this.blockLayer = this.getComponent('BlockLayer');
        this.playerLayer = this.getComponent("PlayerLayer");
        this.initMap(0, ""); //最底层为tileMap层
        this.inputControl.game = this;
    },

    //初始化地图和关卡信息
    initMap: function initMap(level, url) {
        this.level = level;
        this.titleLayer.initPass(this.level);
        this.blockLayer.initPass(this.level);
        this.playerLayer.initPass(this.level, url);
    },

    //移动
    move: function move(direction) {
        this.playerLayer.moveTo(0, 0, direction);
    },

    //放置炸弹
    putBomb: function putBomb() {
        this.playerLayer.putBomb();
    }

});

cc._RFpop();
},{"InputControl":"InputControl"}],"Mount":[function(require,module,exports){
"use strict";
cc._RFpush(module, '81146JrpU1IoLa75jnqlGXv', 'Mount');
// Scripts/Player/Mount.js

var Player = require("Player");
cc.Class({
    "extends": Player,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {}
});

cc._RFpop();
},{"Player":"Player"}],"Pass":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6dc7fU5gx9E6Y+XDk+09FHs', 'Pass');
// Scripts/Map/Pass.js

var MapNode = require("MapNode");
cc.Class({
    "extends": cc.Component,

    properties: {
        mapNode: cc.Prefab,
        pass: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.passes = [[[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 3, 5, 5, 3, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]], [[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]], [[2, 2, 2, 4, 4, 4, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 5, 5, 4, 2, 2, 2], [2, 2, 2, 4, 4, 4, 4, 2, 2, 2]]];
        this.nodes = [];
    },

    //手动创建tileMap背景层
    initTitleByPass: function initTitleByPass(pass, node) {
        var passInfo = this.passes[pass];
        var len = passInfo.length;
        for (var i = 0; i < len; i++) {
            var leng = passInfo[i].length;
            for (var j = 0; j < leng; j++) {
                var mapNode = cc.instantiate(this.mapNode);
                mapNode.parent = node;
                var nodeCode = mapNode.getComponent("MapNode");
                nodeCode.setStyle(passInfo[j][i]);
                nodeCode.setPostion(i, j);
                // this.nodes[i][j] = mapNode ;
            }
        }
    }
});

cc._RFpop();
},{"MapNode":"MapNode"}],"PlayerLayer":[function(require,module,exports){
"use strict";
cc._RFpush(module, '19b33SsvM9HZb+AWkV11aH/', 'PlayerLayer');
// Scripts/Map/PlayerLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        playerPrefab: cc.Prefab,
        bombPrefab: cc.Prefab
    },

    onLoad: function onLoad() {
        if (!this.revivePos) {
            this.revivePos = [[10, 9], [10, 9], [10, 9], [10, 9], [10, 9]];
        }
    },

    //初始化玩家
    initPlayer: function initPlayer(i, j, url) {
        this.player = cc.instantiate(this.playerPrefab);
        this.player.parent = this.node;
        this.playerCode = this.player.getComponent("Player");
        this.playerCode.initPlayerWithUrl(url);
        var pos = this.getOriginPosition(i, j);
        this.player.x = pos.x;
        this.player.y = pos.y;
    },

    //获取角色复活点
    getOriginPosition: function getOriginPosition(i, j) {
        var pos = { x: 0, y: 0 };
        pos.x = this.player.defX + i * this.player.width;
        pos.y = this.player.defY + j * this.player.height;
        pos.x = 0;
        pos.y = 0;
        return pos;
    },

    //初始化玩家位置
    initPass: function initPass(currentPass, url) {
        if (!this.revivePos) {
            this.revivePos = [[10, 9], [10, 9], [10, 9], [10, 9], [10, 9]];
        }
        var pos = this.revivePos[currentPass];
        this.initPlayer(pos[0], pos[1], "");
    },

    //移动玩家到某个点
    moveTo: function moveTo(i, j, direction) {
        this.playerCode.move(i, j, direction);
    },

    //放置炸弹
    putBomb: function putBomb() {
        var bomb = cc.instantiate(this.bombPrefab);
        var bombCode = bomb.getComponent("Bomb");
        bomb.parent = this.node;
        bomb.x = 40;
        bomb.y = 40;
        bombCode.initBombWith(this.playerCode.i, this.playerCode.j, 0);
    }

});

cc._RFpop();
},{}],"Player":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e9ed4QVtF9JTLc+6Crvqlbk', 'Player');
// Scripts/Player/Player.js


var DIRECTION = cc.Enum({
    UP: 1,
    DOWN: 2,
    LEFT: 3,
    RIGHT: 4
});
cc.Class({
    "extends": cc.Component,

    properties: {
        direction: cc.Integer,
        speed: 1,
        i: 0,
        j: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.defX = -282;
        this.defY = 390;
        this.heroAtlas = {};
        this.walks = [[], [0, 1], [0, -1], [-1, 0], [1, 0]];
        this.action = ["", "hero_up", "hero_down", "hero_right", "hero_left"];
    },

    //移动
    move: function move(i, j, direction) {
        this.i = i;
        this.j = j;
        this.node.x = this.defX + i * this.node.width;
        this.node.y = this.defY - j * this.node.height;
        var key = this.action[direction];
        this.play(key);
        var walk = this.walks[direction];
        this.node.x += walk[0] * this.node.width;
        this.node.y += walk[1] * this.node.height;
    },

    //放置炸弹
    putBomb: function putBomb() {},

    //被攻击
    beAttack: function beAttack() {},

    //骑乘坐起
    ridingMount: function ridingMount(type) {},

    //使用物品
    useItem: function useItem() {},

    //更换皮肤
    initPlayerWithUrl: function initPlayerWithUrl(url) {
        var _this = this;

        var self = this;
        if (url == undefined || url == "") {
            url = "Hero/heroAltas";
        }
        self.animation = this.getComponent(cc.Animation);
        self.animation.active = true;
        cc.loader.loadRes(url, cc.SpriteAtlas, function (err, atlas) {
            self.heroAtlas = atlas;
            _this.play("hero_up");
        });
    },

    //创建以key为截点的动画
    createAnimationClips: function createAnimationClips(key, frameCount) {
        var frame = [];
        for (var i = 1; i <= frameCount; i++) {
            console.log(key);
            var spriteFrame = this.heroAtlas.getSpriteFrame(key + "_" + i);
            frame.push(spriteFrame);
        }
        var clip = cc.AnimationClip.createWithSpriteFrames(frame, frameCount);
        clip.name = key;
        clip.wrapMode = cc.WrapMode.Loop;
        this.animation.addClip(clip);
    },

    //播放相应动画
    play: function play(key) {
        if (!this.animation._nameToState[key]) {
            this.createAnimationClips(key, 6);
        }
        this.animation.play(key);
    }

});

cc._RFpop();
},{}],"StartGame":[function(require,module,exports){
"use strict";
cc._RFpush(module, '17486XVSbRNjrbkXLYI2y3P', 'StartGame');
// Scripts/UI/StartGame.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    startGame: function startGame() {
        cc.director.loadScene("GameView");
    },

    openHelpPanel: function openHelpPanel() {
        this.gameControl.showHelpPanel();
    }

});

cc._RFpop();
},{}],"TileLayer":[function(require,module,exports){
"use strict";
cc._RFpush(module, '03e50td3lFEypcwdUJdQIbs', 'TileLayer');
// Scripts/Map/TileLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        pass: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        if (!this.passNode) {
            this.passNode = cc.instantiate(this.pass);
        }
        this.passNode.parent = this.node;
    },

    //初始化关卡
    initPass: function initPass(currentPass) {
        if (!this.passNode) {
            this.passNode = cc.instantiate(this.pass);
            this.passNode.parent = this.node;
        }
        var passCode = this.passNode.getComponent("Pass");
        passCode.initTitleByPass(currentPass, this.node);
    }
});

cc._RFpop();
},{}],"Tipple":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'db221WOgUtN1K3viXuEVMF1', 'Tipple');
// Scripts/Player/Tipple.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}]},{},["TileLayer","Map","MapNode","InputControl","StartGame","PlayerLayer","GameControl","BuildingLayer","Bomb","BlockTile","Block","Pass","BuildSetting","Mount","MapControl","HelpPanel","AStar","Tipple","BlockLayer","Grid","Player","ButtonScaler"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL0FwcGxpY2F0aW9ucy9Db2Nvc0NyZWF0b3IuYXBwL0NvbnRlbnRzL1Jlc291cmNlcy9hcHAuYXNhci9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiYXNzZXRzL1NjcmlwdHMvQXN0YXIvQVN0YXIuanMiLCJhc3NldHMvU2NyaXB0cy9NYXAvQmxvY2tMYXllci5qcyIsImFzc2V0cy9TY3JpcHRzL01hcC9CbG9ja1RpbGUuanMiLCJhc3NldHMvU2NyaXB0cy9NYXAvQmxvY2suanMiLCJhc3NldHMvU2NyaXB0cy9QbGF5ZXIvQm9tYi5qcyIsImFzc2V0cy9TY3JpcHRzL01hcC9CdWlsZFNldHRpbmcuanMiLCJhc3NldHMvU2NyaXB0cy9NYXAvQnVpbGRpbmdMYXllci5qcyIsImFzc2V0cy9TY3JpcHRzL0VmZmVjdC9CdXR0b25TY2FsZXIuanMiLCJhc3NldHMvU2NyaXB0cy9Db250cm9sL0dhbWVDb250cm9sLmpzIiwiYXNzZXRzL1NjcmlwdHMvQXN0YXIvR3JpZC5qcyIsImFzc2V0cy9TY3JpcHRzL1VJL0hlbHBQYW5lbC5qcyIsImFzc2V0cy9TY3JpcHRzL0NvbnRyb2wvSW5wdXRDb250cm9sLmpzIiwiYXNzZXRzL1NjcmlwdHMvQ29udHJvbC9NYXBDb250cm9sLmpzIiwiYXNzZXRzL1NjcmlwdHMvTWFwL01hcE5vZGUuanMiLCJhc3NldHMvU2NyaXB0cy9NYXAvTWFwLmpzIiwiYXNzZXRzL1NjcmlwdHMvUGxheWVyL01vdW50LmpzIiwiYXNzZXRzL1NjcmlwdHMvTWFwL1Bhc3MuanMiLCJhc3NldHMvU2NyaXB0cy9NYXAvUGxheWVyTGF5ZXIuanMiLCJhc3NldHMvU2NyaXB0cy9QbGF5ZXIvUGxheWVyLmpzIiwiYXNzZXRzL1NjcmlwdHMvVUkvU3RhcnRHYW1lLmpzIiwiYXNzZXRzL1NjcmlwdHMvTWFwL1RpbGVMYXllci5qcyIsImFzc2V0cy9TY3JpcHRzL1BsYXllci9UaXBwbGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM5QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2M4NGY2SUJZSk5LZnBKZ1diaUk1SklWJywgJ0FTdGFyJyk7XG4vLyBTY3JpcHRzL0FzdGFyL0FTdGFyLmpzXG5cbnZhciBHcmlkID0gcmVxdWlyZShcIkdyaWRcIik7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgdmlzdGVkTnVtOiAwLFxuICAgICAgICB2aXNpdGVkOiBbXSxcbiAgICAgICAgbWF4WDogMTAsXG4gICAgICAgIG1heFk6IDEwLFxuICAgICAgICBtYXBzOiBbXSxcbiAgICAgICAgY2xvc2U6IFtdLFxuICAgICAgICBvcGVuOiBbXSxcbiAgICAgICAgYXJvdW5kOiBbWzAsIC0xXSwgWzEsIDBdLCBbLTEsIDBdLCBbMCwgMV1dIC8v5Zub5pa55ZCRXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICAvL+afpeaJvui3r+W+hFxuICAgIGZpbmRQYXRoOiBmdW5jdGlvbiBmaW5kUGF0aChzdGFydCwgZW5kKSB7XG4gICAgICAgIHZhciBwYXRoID0gW107XG4gICAgICAgIHRoaXMuc3RhcnQgPSBzdGFydDtcbiAgICAgICAgdGhpcy5lbmQgPSBlbmQ7XG4gICAgICAgIHRoaXMudmlzdGVkTnVtID0gMDtcbiAgICAgICAgdGhpcy52aXNpdGVkID0gW107XG4gICAgICAgIHRoaXMuc3RhcnQuZiA9IHRoaXMuc3RhcnQuZyA9IHRoaXMuc3RhcnQuaCA9IDA7XG5cbiAgICAgICAgcmV0dXJuIHBhdGg7XG4gICAgfSxcblxuICAgIGV1Y2xpZGlhbjogZnVuY3Rpb24gZXVjbGlkaWFuKGdyaWQpIHtcbiAgICAgICAgdmFyIGRpc1ggPSB0aGlzLmVuZC54IC0gZ3JpZC54O1xuICAgICAgICB2YXIgZGlzWSA9IHRoaXMuZW5kLnkgLSBncmlkLnk7XG4gICAgICAgIHJldHVybiBkaXNYICogZGlzWCArIGRpc1kgKiBkaXNZO1xuICAgIH0sXG5cbiAgICBkaWFnb25hbDogZnVuY3Rpb24gZGlhZ29uYWwoZ3JpZCkge1xuICAgICAgICB2YXIgZGlzWCA9IHRoaXMuZW5kLnggLSBncmlkLng7XG4gICAgICAgIHZhciBkaXhZID0gdGhpcy5lbmQueSAtIGdyaWQueTtcbiAgICAgICAgaWYgKGRpc1ggPCAwKSBkaXNYICo9IC0xO1xuICAgICAgICBpZiAoZGlzWSA8IDApIGRpc1kgKj0gLTE7XG4gICAgICAgIHZhciBtaW4gPSBkaXNYIDwgZGlzWSA/IGRpc1ggOiBkaXNZO1xuICAgICAgICByZXR1cm4gbWluICogTWF0aC5TUVJUMiArIChkaXNYICsgZGlzWSAtIDIgKiBtaW4pO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlNDg4NkthM3lsSTRyd3c2ZnhneVk0bicsICdCbG9ja0xheWVyJyk7XG4vLyBTY3JpcHRzL01hcC9CbG9ja0xheWVyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBibG9ja1RpbGU6IGNjLlByZWZhYlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuXG4gICAgaW5pdFBhc3M6IGZ1bmN0aW9uIGluaXRQYXNzKGN1cnJlbnRQYXNzKSB7XG4gICAgICAgIGlmICghdGhpcy5wYXNzTm9kZSkge1xuICAgICAgICAgICAgdGhpcy5ibG9ja1RpbGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJsb2NrVGlsZSk7XG4gICAgICAgICAgICB0aGlzLmJsb2NrVGlsZS5wYXJlbnQgPSB0aGlzLm5vZGU7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGJsb2NrVGlsZUNvZGUgPSB0aGlzLmJsb2NrVGlsZS5nZXRDb21wb25lbnQoXCJCbG9ja1RpbGVcIik7XG4gICAgICAgIGJsb2NrVGlsZUNvZGUuaW5pdEJsb2NrQnlQYXNzKGN1cnJlbnRQYXNzLCB0aGlzLm5vZGUpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnM2QxODBiSm5wVkdJbzRkOUsrZUc3YWInLCAnQmxvY2tUaWxlJyk7XG4vLyBTY3JpcHRzL01hcC9CbG9ja1RpbGUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGJsb2NrOiBjYy5QcmVmYWJcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuYmxvY2tzID0gW1tbMCwgMCwgMCwgNiwgMCwgMCwgMCwgMTYsIDE3LCA2XSwgWzAsIDE3LCAwLCAwLCAwLCAwLCAwLCAwLCAwLCA2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMCwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzE2LCAxNywgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDAsIDAsIDAsIDYsIDAsIDAsIDAsIDE3LCAxNl0sIFswLCAwLCAwLCAwLCAwLCA2LCA2LCAwLCAwLCAwXSwgWzE2LCAxNywgMCwgMCwgNiwgMCwgMCwgMCwgMTcsIDZdLCBbNiwgMCwgMCwgMCwgMCwgNiwgNiwgMCwgMCwgMF0sIFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwXV0sIFtbMCwgMCwgMCwgNiwgMCwgMCwgMCwgMTYsIDE3LCA2XSwgWzAsIDE3LCAwLCAwLCAwLCAwLCAwLCAwLCAwLCA2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCA2LCAwLCAxNiwgMF0sIFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwXV0sIFtbMCwgMCwgMCwgNiwgMCwgMCwgMCwgMTYsIDE3LCA2XSwgWzAsIDE3LCAwLCAwLCAwLCAwLCAwLCAwLCAwLCA2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCA2LCAwLCAxNiwgMF0sIFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwXV0sIFtbMCwgMCwgMCwgNiwgMCwgMCwgMCwgMTYsIDE3LCA2XSwgWzAsIDE3LCAwLCAwLCAwLCAwLCAwLCAwLCAwLCA2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCA2LCAwLCAxNiwgMF0sIFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwXV0sIFtbMCwgMCwgMCwgNiwgMCwgMCwgMCwgMTYsIDE3LCA2XSwgWzAsIDE3LCAwLCAwLCAwLCAwLCAwLCAwLCAwLCA2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCAwLCAwLCAxNywgMTZdLCBbMCwgMTYsIDAsIDAsIDAsIDYsIDAsIDAsIDE3LCAxNl0sIFswLCAxNiwgMCwgMCwgMCwgNiwgMCwgMCwgMTcsIDE2XSwgWzAsIDE2LCAwLCAwLCAwLCA2LCA2LCAwLCAxNiwgMF0sIFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAwXV1dO1xuICAgIH0sXG5cbiAgICAvL+aJi+WKqOWIm+W7unRpbGVNYXDog4zmma/lsYJcbiAgICBpbml0QmxvY2tCeVBhc3M6IGZ1bmN0aW9uIGluaXRCbG9ja0J5UGFzcyhwYXNzLCBub2RlKSB7XG4gICAgICAgIHZhciBibG9ja0luZm8gPSB0aGlzLmJsb2Nrc1twYXNzXTtcbiAgICAgICAgdmFyIGxlbiA9IGJsb2NrSW5mby5sZW5ndGg7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBsZW5nID0gYmxvY2tJbmZvW2ldLmxlbmd0aDtcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgbGVuZzsgaisrKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN0eWxlID0gYmxvY2tJbmZvW2pdW2ldO1xuICAgICAgICAgICAgICAgIGlmIChzdHlsZSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgYmxvY2sgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJsb2NrKTtcbiAgICAgICAgICAgICAgICBibG9jay5wYXJlbnQgPSBub2RlO1xuICAgICAgICAgICAgICAgIHZhciBub2RlQ29kZSA9IGJsb2NrLmdldENvbXBvbmVudChcIkJsb2NrXCIpO1xuICAgICAgICAgICAgICAgIG5vZGVDb2RlLnNldEJveFN0eWxlKHN0eWxlKTtcbiAgICAgICAgICAgICAgICBub2RlQ29kZS5zZXRQb3N0aW9uKGksIGopO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc0OTM5N3M3RXVWTEdyUW5sK0VQTDU3QicsICdCbG9jaycpO1xuLy8gU2NyaXB0cy9NYXAvQmxvY2suanNcblxudmFyIFJld2FyZFR5cGUgPSBjYy5FbnVtKHt9KTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICByZXdhcmRUeXBlOiAtMSxcbiAgICAgICAgZGVmWDogLTI3MCxcbiAgICAgICAgZGVmWTogMzYxLFxuICAgICAgICBkZWZXOiA2MCxcbiAgICAgICAgZGVmSDogNjZcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBzcHJpdGUgPSB0aGlzLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICBpZiAoc3ByaXRlLnNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICB0aGlzLnJlc2l6ZShzcHJpdGUuc3ByaXRlRnJhbWUuZ2V0UmVjdCgpKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFuaW1hdGlvbiA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG4gICAgICAgIHRoaXMuYW5pbWF0aW9uLm9uKFwic3RvcFwiLCB0aGlzLnBsYXlFZmZlY3RDb21wbGV0ZSwgdGhpcyk7XG4gICAgfSxcblxuICAgIC8v56CW5Z2X6KKr54K4IOmAmui/h+WlluWKseexu+Wei+WIpOaWreaYr+WQpueUn+aIkOWlluWKseeJqeWTge+8jOWSjOWlluWKseeJqeWTgeeahOenjeexu1xuICAgIGJvb21CbG9jazogZnVuY3Rpb24gYm9vbUJsb2NrKHJld2FyZFR5cGUpIHtcblxuICAgICAgICBpZiAocmV3YXJkVHlwZSAhPSAtMSkgdGhpcy5nZXJuYXRlUmV3YXJkKHJld2FyZFR5cGUpO2Vsc2UgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBwbGF5RWZmZWN0Q29tcGxldGU6IGZ1bmN0aW9uIHBsYXlFZmZlY3RDb21wbGV0ZSgpIHtcbiAgICAgICAgdGhpcy5hbmltYXRpb24ubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgLy/nlJ/miJDlpZblirFcbiAgICBnZXJuYXRlUmV3YXJkOiBmdW5jdGlvbiBnZXJuYXRlUmV3YXJkKHJld2FyZCkge30sXG5cbiAgICAvL+aSreaUvueIhueCuOeJueaViFxuICAgIHBsYXlCb21iRWZmZWN0OiBmdW5jdGlvbiBwbGF5Qm9tYkVmZmVjdCgpIHtcbiAgICAgICAgdmFyIGFuaW1hdGlvbiA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG4gICAgICAgIGFuaW1hdGlvbi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyhcIk1hcC9ibG9jay9ib21iXCIsIGNjLlNwcml0ZUF0bGFzLCBmdW5jdGlvbiAoZXJyLCBhdGxhcykge1xuICAgICAgICAgICAgdmFyIHNwcml0ZUZyYW1lcyA9IGF0bGFzLmdldFNwcml0ZUZyYW1lcygpO1xuXG4gICAgICAgICAgICB2YXIgY2xpcCA9IGNjLkFuaW1hdGlvbkNsaXAuY3JlYXRlV2l0aFNwcml0ZUZyYW1lcyhzcHJpdGVGcmFtZXMsIDEyKTtcbiAgICAgICAgICAgIGNsaXAubmFtZSA9ICdydW4nO1xuICAgICAgICAgICAgY2xpcC53cmFwTW9kZSA9IGNjLldyYXBNb2RlLkRlZmF1bHQ7XG4gICAgICAgICAgICBhbmltYXRpb24uYWRkQ2xpcChjbGlwKTtcbiAgICAgICAgICAgIGFuaW1hdGlvbi5wbGF5KCdydW4nKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIC8v5ZCD5o6J5b2T5YmN5qC85a2Q5Lit55qE5aWW5YqxIOW5tumUgOavgeWvueixoVxuICAgIGJpdGVSZXdhcmQ6IGZ1bmN0aW9uIGJpdGVSZXdhcmQoKSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgLy/orr7nva7moLzlrZDmoLflvI/vvIzlubbkuLrmoLzlrZDorr7nva7moLzlrZDnorDmkp7kvZPnp69cbiAgICBzZXRCb3hTdHlsZTogZnVuY3Rpb24gc2V0Qm94U3R5bGUoc3R5bGUpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB2YXIgc3ByaXRlID0gc2VsZi5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMoXCJNYXAvYmxvY2svYmxvY2tBbHRhc1wiLCBjYy5TcHJpdGVBdGxhcywgZnVuY3Rpb24gKGVyciwgYXRsYXMpIHtcbiAgICAgICAgICAgIHZhciBmcmFtZSA9IGF0bGFzLmdldFNwcml0ZUZyYW1lKCdib3gnICsgc3R5bGUpO1xuICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gZnJhbWU7XG4gICAgICAgICAgICBzZWxmLnJlc2l6ZShzcHJpdGUuc3ByaXRlRnJhbWUuZ2V0UmVjdCgpKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIC8v6K6+572u6IqC54K55aSn5bCP5ZKM56Kw5pKe5L2T56evXG4gICAgcmVzaXplOiBmdW5jdGlvbiByZXNpemUoc2l6ZSkge1xuICAgICAgICB0aGlzLm5vZGUud2lkdGggPSBzaXplLndpZHRoO1xuICAgICAgICB0aGlzLm5vZGUuaGVpZ2h0ID0gc2l6ZS5oZWlnaHQ7XG4gICAgICAgIHZhciBib3ggPSB0aGlzLmdldENvbXBvbmVudChjYy5Cb3hDb2xsaWRlcik7XG4gICAgICAgIGJveC5zaXplID0gc2l6ZTtcbiAgICB9LFxuXG4gICAgLy/orr7nva7kvY3nva5cbiAgICBzZXRQb3N0aW9uOiBmdW5jdGlvbiBzZXRQb3N0aW9uKGksIGopIHtcbiAgICAgICAgdGhpcy5ub2RlLnggPSBpICogdGhpcy5kZWZXICsgdGhpcy5kZWZYO1xuICAgICAgICB0aGlzLm5vZGUueSA9IC1qICogdGhpcy5kZWZIICsgdGhpcy5kZWZZO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICczNmQ4Y3FHUlJGQ2o2NG4rUkE5enRsOScsICdCb21iJyk7XG4vLyBTY3JpcHRzL1BsYXllci9Cb21iLmpzXG5cbnZhciBCb29tRXZlbnQgPSBjYy5FbnVtKHtcbiAgICBCT09NX1JPVU5EOiBcImJvb21Sb3VuZFwiLFxuICAgIEJPT01fT1ZFUjogXCJib29tT3ZlclwiXG59KTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBhdHRhY2tSb3VuZDogMSxcbiAgICAgICAgYm9tYkVmZmVjdDoge1xuICAgICAgICAgICAgdHlwZTogY2MuQW5pbWF0aW9uLFxuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGxcbiAgICAgICAgfSxcbiAgICAgICAgYm9tYlRpbWU6IDQgfSxcblxuICAgIC8v54iG54K45LqL5Lu2XG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMudHlwZXMgPSBbXCJIZXJvL2JvbWJcIiwgXCJIZXJvL2JvbWJcIiwgXCJIZXJvL2JvbWJcIiwgXCJIZXJvL2JvbWIxXCIsIFwiSGVyby9ib21iMVwiLCBcIkhlcm8vYm9tYjFcIl07XG4gICAgfSxcblxuICAgIC8v5ZyoaSxq6IqC54K555Sf5Lqn5LiA5LiqdHlwZeexu+Wei+eahOeCuOW8uVxuICAgIGluaXRCb21iV2l0aDogZnVuY3Rpb24gaW5pdEJvbWJXaXRoKHR5cGUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHZhciB1cmwgPSB0aGlzLnR5cGVzW3R5cGVdO1xuICAgICAgICBzZWxmLmFuaW1hdGlvbiA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG4gICAgICAgIHNlbGYuYW5pbWF0aW9uLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKHVybCwgY2MuU3ByaXRlQXRsYXMsIGZ1bmN0aW9uIChlcnIsIGF0bGFzKSB7XG4gICAgICAgICAgICBzZWxmLmhlcm9BdGxhcyA9IGF0bGFzO1xuICAgICAgICAgICAgX3RoaXMucGxheShcImJvbWJcIik7XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICAvL+WIm+W7uuS7pWtleeS4uuaIqueCueeahOWKqOeUu1xuICAgIGNyZWF0ZUFuaW1hdGlvbkNsaXBzOiBmdW5jdGlvbiBjcmVhdGVBbmltYXRpb25DbGlwcyhrZXksIGZyYW1lQ291bnQpIHtcbiAgICAgICAgdmFyIGZyYW1lID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDw9IGZyYW1lQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coa2V5KTtcbiAgICAgICAgICAgIHZhciBzcHJpdGVGcmFtZSA9IHRoaXMuaGVyb0F0bGFzLmdldFNwcml0ZUZyYW1lKGtleSArIGkpO1xuICAgICAgICAgICAgZnJhbWUucHVzaChzcHJpdGVGcmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNsaXAgPSBjYy5BbmltYXRpb25DbGlwLmNyZWF0ZVdpdGhTcHJpdGVGcmFtZXMoZnJhbWUsIGZyYW1lQ291bnQpO1xuICAgICAgICBjbGlwLm5hbWUgPSBrZXk7XG4gICAgICAgIGNsaXAud3JhcE1vZGUgPSBjYy5XcmFwTW9kZS5Mb29wO1xuICAgICAgICB0aGlzLmFuaW1hdGlvbi5hZGRDbGlwKGNsaXApO1xuICAgIH0sXG5cbiAgICAvL+aSreaUvuebuOW6lOWKqOeUu1xuICAgIHBsYXk6IGZ1bmN0aW9uIHBsYXkoa2V5KSB7XG4gICAgICAgIGlmICghdGhpcy5hbmltYXRpb24uX25hbWVUb1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgIHRoaXMuY3JlYXRlQW5pbWF0aW9uQ2xpcHMoa2V5LCA0KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFuaW1hdGlvbi5wbGF5KGtleSk7XG4gICAgfSxcblxuICAgIC8v54iG54K4IOW5tumAmuefpeeIhueCuOiMg+WbtFxuICAgIGJvbWJUaGlzTWluZTogZnVuY3Rpb24gYm9tYlRoaXNNaW5lKCkge1xuICAgICAgICB2YXIgcm91bmQ7XG4gICAgICAgIHRoaXMubm9kZS5lbWl0KEJvb21FdmVudC5CT09NX1JPVU5ELCB7fSk7XG4gICAgfSxcblxuICAgIC8v6I635Y+W54iG54K46IyD5Zu0XG4gICAgZ2V0Qm9vbVJvdW5kOiBmdW5jdGlvbiBnZXRCb29tUm91bmQoKSB7fVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc3YWNlYXcwamc5Q1RhTkYySzdxcktUSicsICdCdWlsZFNldHRpbmcnKTtcbi8vIFNjcmlwdHMvTWFwL0J1aWxkU2V0dGluZy5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMjg5YmFLSHZrUlB6b0dFUlZzZStnUzQnLCAnQnVpbGRpbmdMYXllcicpO1xuLy8gU2NyaXB0cy9NYXAvQnVpbGRpbmdMYXllci5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZWFlNjBiVVJzcEFUSVhQYURCM1VTSkgnLCAnQnV0dG9uU2NhbGVyJyk7XG4vLyBTY3JpcHRzL0VmZmVjdC9CdXR0b25TY2FsZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBwcmVzc2VkU2NhbGU6IDEsXG4gICAgICAgIHRyYW5zRHVyYXRpb246IDBcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5pbml0U2NhbGUgPSB0aGlzLm5vZGUuc2NhbGU7XG4gICAgICAgIHNlbGYuYnV0dG9uID0gc2VsZi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc2VsZi5zY2FsZURvd25BY3Rpb24gPSBjYy5zY2FsZVRvKHNlbGYudHJhbnNEdXJhdGlvbiwgc2VsZi5wcmVzc2VkU2NhbGUpO1xuICAgICAgICBzZWxmLnNjYWxlVXBBY3Rpb24gPSBjYy5zY2FsZVRvKHNlbGYudHJhbnNEdXJhdGlvbiwgc2VsZi5pbml0U2NhbGUpO1xuICAgICAgICBmdW5jdGlvbiBvblRvdWNoRG93bihldmVudCkge1xuICAgICAgICAgICAgdGhpcy5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICAgICAgdGhpcy5ydW5BY3Rpb24oc2VsZi5zY2FsZURvd25BY3Rpb24pO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG9uVG91Y2hVcChldmVudCkge1xuICAgICAgICAgICAgdGhpcy5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICAgICAgdGhpcy5ydW5BY3Rpb24oc2VsZi5zY2FsZVVwQWN0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoc3RhcnQnLCBvblRvdWNoRG93biwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGVuZCcsIG9uVG91Y2hVcCwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGNhbmNlbCcsIG9uVG91Y2hVcCwgdGhpcy5ub2RlKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzFjOGZmOGY0NmREYTc0OTNSUmRTdW4zJywgJ0dhbWVDb250cm9sJyk7XG4vLyBTY3JpcHRzL0NvbnRyb2wvR2FtZUNvbnRyb2wuanNcblxudmFyIEhlbHBQYW5lbCA9IHJlcXVpcmUoJ0hlbHBQYW5lbCcpO1xudmFyIFN0YXJ0R2FtZSA9IHJlcXVpcmUoJ1N0YXJ0R2FtZScpO1xuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBoZWxwUGFuZWw6IHtcbiAgICAgICAgICAgIHR5cGU6IEhlbHBQYW5lbCxcbiAgICAgICAgICAgICdkZWZhdWx0JzogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBzdGFydEdhbWU6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0YXJ0R2FtZSxcbiAgICAgICAgICAgICdkZWZhdWx0JzogbnVsbFxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLnN0YXJ0R2FtZS5nYW1lQ29udHJvbCA9IHRoaXM7XG4gICAgICAgIHRoaXMuaGVscFBhbmVsLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc3RhcnRHYW1lLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICB9LFxuXG4gICAgc2hvd0hlbHBQYW5lbDogZnVuY3Rpb24gc2hvd0hlbHBQYW5lbCgpIHtcbiAgICAgICAgdGhpcy5oZWxwUGFuZWwubm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLnN0YXJ0R2FtZS5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZDAzOWJpQ0w5NUJmNU1aY0VTNXo4OEInLCAnR3JpZCcpO1xuLy8gU2NyaXB0cy9Bc3Rhci9HcmlkLmpzXG5cbi8vIGNvbnN0IEdyaWQgPSByZXF1aXJlKFwiR3JpZFwiKVxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHg6IDAsXG4gICAgICAgIHk6IDAsXG4gICAgICAgIGc6IDAuMCxcbiAgICAgICAgZjogMC4wLFxuICAgICAgICBoOiAwLjAsXG4gICAgICAgIHdhbGtBYmxlOiBjYy5Cb29sZWFuLFxuICAgICAgICBtYXhSYXc6IDEwLFxuICAgICAgICBtYXhDb2w6IDlcbiAgICB9LFxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICAvL+WIneWni+WMlkHmmJ/moLzlrZBcbiAgICBpbml0OiBmdW5jdGlvbiBpbml0KHgsIHksIGcsIGYsIG1vdmVBYmxlKSB7XG4gICAgICAgIHRoaXMueCA9IHg7XG4gICAgICAgIHRoaXMueSA9IHk7XG4gICAgICAgIHRoaXMuZyA9IGc7XG4gICAgICAgIHRoaXMuZiA9IGY7XG4gICAgICAgIHRoaXMubW92ZUFibGUgPSBtb3ZlQWJsZTtcbiAgICAgICAgdGhpcy5oID0gZyAqIDEwICsgZiAqIDEwO1xuICAgIH0sXG5cbiAgICByZXNldDogZnVuY3Rpb24gcmVzZXQoKSB7XG4gICAgICAgIHRoaXMueCA9IDA7XG4gICAgICAgIHRoaXMueSA9IDA7XG4gICAgICAgIHRoaXMuZiA9IDA7XG4gICAgICAgIHRoaXMuZyA9IDA7XG4gICAgICAgIHRoaXMuaCA9IDA7XG4gICAgICAgIHRoaXMud2Fsa0FibGUgPSBmYWxzZTtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYWIyNmZySWx4WkpWNXBqTGJEVWhMRzgnLCAnSGVscFBhbmVsJyk7XG4vLyBTY3JpcHRzL1VJL0hlbHBQYW5lbC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHt9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICAgIHN0YXJ0R2FtZTogZnVuY3Rpb24gc3RhcnRHYW1lKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lVmlld1wiKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzE1OTVkM3hvcUpGZ28yNy9QWFViemxKJywgJ0lucHV0Q29udHJvbCcpO1xuLy8gU2NyaXB0cy9Db250cm9sL0lucHV0Q29udHJvbC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHt9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIC8vIHRoaXMuYmxvY2tOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5ibG9jayk7XG4gICAgICAgIC8vIHRoaXMuYmxvY2tOb2RlLnBhcmVudCA9IHRoaXMubm9kZSA7XG4gICAgICAgIC8vIHRoaXMuYmxvY2tOb2RlLnggPSAtMjgwO1xuICAgICAgICAvLyB0aGlzLmJsb2NrTm9kZS55ID0gLTQwMCA7XG4gICAgfSxcblxuICAgIC8vIHBsYXlFZmZlY3Q6ZnVuY3Rpb24oKVxuICAgIC8vIHtcbiAgICAvLyAgICAgdmFyIGJsb2NrTm9kZSA9IHRoaXMuYmxvY2tOb2RlLmdldENvbXBvbmVudChcIkJsb2NrXCIpO1xuICAgIC8vICAgICBibG9ja05vZGUucGxheUJvbWJFZmZlY3QoKTtcbiAgICAvLyB9XG5cbiAgICAvL+enu+WKqOeOqeWutlxuICAgIG1vdmU6IGZ1bmN0aW9uIG1vdmUoZXZlbnQsIGRpcmVjdGlvbikge1xuICAgICAgICBjb25zb2xlLmxvZyhkaXJlY3Rpb24pO1xuICAgICAgICB0aGlzLmdhbWUubW92ZShkaXJlY3Rpb24pO1xuICAgIH0sXG5cbiAgICAvL+aUvue9rueCuOW8uVxuICAgIHB1dEJvbWI6IGZ1bmN0aW9uIHB1dEJvbWIoKSB7XG4gICAgICAgIHRoaXMuZ2FtZS5wdXRCb21iKCk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzk0YjJhQ3dvNnhGVVkxVDNZbldGaXorJywgJ01hcENvbnRyb2wnKTtcbi8vIFNjcmlwdHMvQ29udHJvbC9NYXBDb250cm9sLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuXG4gICAgZ2V0TWFwQnlMZXZlbDogZnVuY3Rpb24gZ2V0TWFwQnlMZXZlbChsZXZlbCkge1xuICAgICAgICB2YXIgbWFwID0gW107XG5cbiAgICAgICAgcmV0dXJuIG1hcDtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzBiODY1dXdNY3RGL1krSXh3K3JreUJlJywgJ01hcE5vZGUnKTtcbi8vIFNjcmlwdHMvTWFwL01hcE5vZGUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHRpbGVNYXBOb2RlOiB7XG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGUsXG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgICAgICB9LFxuICAgICAgICBkZWZYOiAtMjcwLFxuICAgICAgICBkZWZZOiAzNjEsXG4gICAgICAgIGRlZlc6IDYwLFxuICAgICAgICBkZWZIOiA2MFxuXG4gICAgfSxcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuXG4gICAgLy/orr7nva7kvY3nva5cbiAgICBzZXRQb3N0aW9uOiBmdW5jdGlvbiBzZXRQb3N0aW9uKGksIGopIHtcbiAgICAgICAgdGhpcy5ub2RlLnggPSBpICogdGhpcy5kZWZXICsgdGhpcy5kZWZYO1xuICAgICAgICB0aGlzLm5vZGUueSA9IC1qICogdGhpcy5kZWZIICsgdGhpcy5kZWZZO1xuICAgIH0sXG5cbiAgICAvL+iuvue9ruagt+W8j1xuICAgIHNldFN0eWxlOiBmdW5jdGlvbiBzZXRTdHlsZShzdHlsZSkge1xuICAgICAgICB2YXIgc3ByaXRlID0gdGhpcy5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMoXCJNYXAvdGlsZS90aWxlQWx0YXNcIiwgY2MuU3ByaXRlQXRsYXMsIGZ1bmN0aW9uIChlcnIsIGF0bGFzKSB7XG4gICAgICAgICAgICB2YXIgZnJhbWUgPSBhdGxhcy5nZXRTcHJpdGVGcmFtZSgnbm9kZScgKyBzdHlsZSk7XG4gICAgICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBmcmFtZTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzA4MDZjZTYzcTVCMUxCQ2V5U1hwbVVmJywgJ01hcCcpO1xuLy8gU2NyaXB0cy9NYXAvTWFwLmpzXG5cbnZhciBJbnB1dENvbnRyb2wgPSByZXF1aXJlKFwiSW5wdXRDb250cm9sXCIpO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBpbnB1dENvbnRyb2w6IElucHV0Q29udHJvbFxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy50aXRsZUxheWVyID0gdGhpcy5nZXRDb21wb25lbnQoXCJUaWxlTGF5ZXJcIik7XG4gICAgICAgIHRoaXMuYmxvY2tMYXllciA9IHRoaXMuZ2V0Q29tcG9uZW50KCdCbG9ja0xheWVyJyk7XG4gICAgICAgIHRoaXMucGxheWVyTGF5ZXIgPSB0aGlzLmdldENvbXBvbmVudChcIlBsYXllckxheWVyXCIpO1xuICAgICAgICB0aGlzLmluaXRNYXAoMCwgXCJcIik7IC8v5pyA5bqV5bGC5Li6dGlsZU1hcOWxglxuICAgICAgICB0aGlzLmlucHV0Q29udHJvbC5nYW1lID0gdGhpcztcbiAgICB9LFxuXG4gICAgLy/liJ3lp4vljJblnLDlm77lkozlhbPljaHkv6Hmga9cbiAgICBpbml0TWFwOiBmdW5jdGlvbiBpbml0TWFwKGxldmVsLCB1cmwpIHtcbiAgICAgICAgdGhpcy5sZXZlbCA9IGxldmVsO1xuICAgICAgICB0aGlzLnRpdGxlTGF5ZXIuaW5pdFBhc3ModGhpcy5sZXZlbCk7XG4gICAgICAgIHRoaXMuYmxvY2tMYXllci5pbml0UGFzcyh0aGlzLmxldmVsKTtcbiAgICAgICAgdGhpcy5wbGF5ZXJMYXllci5pbml0UGFzcyh0aGlzLmxldmVsLCB1cmwpO1xuICAgIH0sXG5cbiAgICAvL+enu+WKqFxuICAgIG1vdmU6IGZ1bmN0aW9uIG1vdmUoZGlyZWN0aW9uKSB7XG4gICAgICAgIHRoaXMucGxheWVyTGF5ZXIubW92ZVRvKDAsIDAsIGRpcmVjdGlvbik7XG4gICAgfSxcblxuICAgIC8v5pS+572u54K45by5XG4gICAgcHV0Qm9tYjogZnVuY3Rpb24gcHV0Qm9tYigpIHtcbiAgICAgICAgdGhpcy5wbGF5ZXJMYXllci5wdXRCb21iKCk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzgxMTQ2SnJwVTFJb0xhNzVqbnFsR1h2JywgJ01vdW50Jyk7XG4vLyBTY3JpcHRzL1BsYXllci9Nb3VudC5qc1xuXG52YXIgUGxheWVyID0gcmVxdWlyZShcIlBsYXllclwiKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogUGxheWVyLFxuXG4gICAgcHJvcGVydGllczoge30sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzZkYzdmVTVneDlFNlkrWERrKzA5RkhzJywgJ1Bhc3MnKTtcbi8vIFNjcmlwdHMvTWFwL1Bhc3MuanNcblxudmFyIE1hcE5vZGUgPSByZXF1aXJlKFwiTWFwTm9kZVwiKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBtYXBOb2RlOiBjYy5QcmVmYWIsXG4gICAgICAgIHBhc3M6IDBcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMucGFzc2VzID0gW1tbMiwgMiwgMiwgNCwgNCwgNCwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCAzLCA1LCA1LCAzLCAyLCAyLCAyXSwgWzIsIDIsIDIsIDMsIDUsIDUsIDMsIDIsIDIsIDJdLCBbMiwgMiwgMiwgMywgNSwgNSwgMywgMiwgMiwgMl0sIFsyLCAyLCAyLCAzLCA1LCA1LCAzLCAyLCAyLCAyXSwgWzIsIDIsIDIsIDMsIDUsIDUsIDMsIDIsIDIsIDJdLCBbMiwgMiwgMiwgMywgNSwgNSwgMywgMiwgMiwgMl0sIFsyLCAyLCAyLCAzLCA1LCA1LCAzLCAyLCAyLCAyXSwgWzIsIDIsIDIsIDMsIDUsIDUsIDMsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNCwgNCwgNCwgMiwgMiwgMl1dLCBbWzIsIDIsIDIsIDQsIDQsIDQsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA1LCA1LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDUsIDUsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA1LCA1LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDUsIDUsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA1LCA1LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDQsIDQsIDQsIDIsIDIsIDJdXSwgW1syLCAyLCAyLCA0LCA0LCA0LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDUsIDUsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA1LCA1LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDUsIDUsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA1LCA1LCA0LCAyLCAyLCAyXSwgWzIsIDIsIDIsIDQsIDUsIDUsIDQsIDIsIDIsIDJdLCBbMiwgMiwgMiwgNCwgNSwgNSwgNCwgMiwgMiwgMl0sIFsyLCAyLCAyLCA0LCA0LCA0LCA0LCAyLCAyLCAyXV1dO1xuICAgICAgICB0aGlzLm5vZGVzID0gW107XG4gICAgfSxcblxuICAgIC8v5omL5Yqo5Yib5bu6dGlsZU1hcOiDjOaZr+WxglxuICAgIGluaXRUaXRsZUJ5UGFzczogZnVuY3Rpb24gaW5pdFRpdGxlQnlQYXNzKHBhc3MsIG5vZGUpIHtcbiAgICAgICAgdmFyIHBhc3NJbmZvID0gdGhpcy5wYXNzZXNbcGFzc107XG4gICAgICAgIHZhciBsZW4gPSBwYXNzSW5mby5sZW5ndGg7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBsZW5nID0gcGFzc0luZm9baV0ubGVuZ3RoO1xuICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBsZW5nOyBqKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgbWFwTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFwTm9kZSk7XG4gICAgICAgICAgICAgICAgbWFwTm9kZS5wYXJlbnQgPSBub2RlO1xuICAgICAgICAgICAgICAgIHZhciBub2RlQ29kZSA9IG1hcE5vZGUuZ2V0Q29tcG9uZW50KFwiTWFwTm9kZVwiKTtcbiAgICAgICAgICAgICAgICBub2RlQ29kZS5zZXRTdHlsZShwYXNzSW5mb1tqXVtpXSk7XG4gICAgICAgICAgICAgICAgbm9kZUNvZGUuc2V0UG9zdGlvbihpLCBqKTtcbiAgICAgICAgICAgICAgICAvLyB0aGlzLm5vZGVzW2ldW2pdID0gbWFwTm9kZSA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzE5YjMzU3N2TTlIWmIrQVdrVjExYUgvJywgJ1BsYXllckxheWVyJyk7XG4vLyBTY3JpcHRzL01hcC9QbGF5ZXJMYXllci5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcGxheWVyUHJlZmFiOiBjYy5QcmVmYWIsXG4gICAgICAgIGJvbWJQcmVmYWI6IGNjLlByZWZhYlxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLnJldml2ZVBvcykge1xuICAgICAgICAgICAgdGhpcy5yZXZpdmVQb3MgPSBbWzEwLCA5XSwgWzEwLCA5XSwgWzEwLCA5XSwgWzEwLCA5XSwgWzEwLCA5XV07XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy/liJ3lp4vljJbnjqnlrrZcbiAgICBpbml0UGxheWVyOiBmdW5jdGlvbiBpbml0UGxheWVyKGksIGosIHVybCkge1xuICAgICAgICB0aGlzLnBsYXllciA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGxheWVyUHJlZmFiKTtcbiAgICAgICAgdGhpcy5wbGF5ZXIucGFyZW50ID0gdGhpcy5ub2RlO1xuICAgICAgICB0aGlzLnBsYXllckNvZGUgPSB0aGlzLnBsYXllci5nZXRDb21wb25lbnQoXCJQbGF5ZXJcIik7XG4gICAgICAgIHRoaXMucGxheWVyQ29kZS5pbml0UGxheWVyV2l0aFVybCh1cmwpO1xuICAgICAgICB2YXIgcG9zID0gdGhpcy5nZXRPcmlnaW5Qb3NpdGlvbihpLCBqKTtcbiAgICAgICAgdGhpcy5wbGF5ZXIueCA9IHBvcy54O1xuICAgICAgICB0aGlzLnBsYXllci55ID0gcG9zLnk7XG4gICAgfSxcblxuICAgIC8v6I635Y+W6KeS6Imy5aSN5rS754K5XG4gICAgZ2V0T3JpZ2luUG9zaXRpb246IGZ1bmN0aW9uIGdldE9yaWdpblBvc2l0aW9uKGksIGopIHtcbiAgICAgICAgdmFyIHBvcyA9IHsgeDogMCwgeTogMCB9O1xuICAgICAgICBwb3MueCA9IHRoaXMucGxheWVyLmRlZlggKyBpICogdGhpcy5wbGF5ZXIud2lkdGg7XG4gICAgICAgIHBvcy55ID0gdGhpcy5wbGF5ZXIuZGVmWSArIGogKiB0aGlzLnBsYXllci5oZWlnaHQ7XG4gICAgICAgIHBvcy54ID0gMDtcbiAgICAgICAgcG9zLnkgPSAwO1xuICAgICAgICByZXR1cm4gcG9zO1xuICAgIH0sXG5cbiAgICAvL+WIneWni+WMlueOqeWutuS9jee9rlxuICAgIGluaXRQYXNzOiBmdW5jdGlvbiBpbml0UGFzcyhjdXJyZW50UGFzcywgdXJsKSB7XG4gICAgICAgIGlmICghdGhpcy5yZXZpdmVQb3MpIHtcbiAgICAgICAgICAgIHRoaXMucmV2aXZlUG9zID0gW1sxMCwgOV0sIFsxMCwgOV0sIFsxMCwgOV0sIFsxMCwgOV0sIFsxMCwgOV1dO1xuICAgICAgICB9XG4gICAgICAgIHZhciBwb3MgPSB0aGlzLnJldml2ZVBvc1tjdXJyZW50UGFzc107XG4gICAgICAgIHRoaXMuaW5pdFBsYXllcihwb3NbMF0sIHBvc1sxXSwgXCJcIik7XG4gICAgfSxcblxuICAgIC8v56e75Yqo546p5a625Yiw5p+Q5Liq54K5XG4gICAgbW92ZVRvOiBmdW5jdGlvbiBtb3ZlVG8oaSwgaiwgZGlyZWN0aW9uKSB7XG4gICAgICAgIHRoaXMucGxheWVyQ29kZS5tb3ZlKGksIGosIGRpcmVjdGlvbik7XG4gICAgfSxcblxuICAgIC8v5pS+572u54K45by5XG4gICAgcHV0Qm9tYjogZnVuY3Rpb24gcHV0Qm9tYigpIHtcbiAgICAgICAgdmFyIGJvbWIgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJvbWJQcmVmYWIpO1xuICAgICAgICB2YXIgYm9tYkNvZGUgPSBib21iLmdldENvbXBvbmVudChcIkJvbWJcIik7XG4gICAgICAgIGJvbWIucGFyZW50ID0gdGhpcy5ub2RlO1xuICAgICAgICBib21iLnggPSA0MDtcbiAgICAgICAgYm9tYi55ID0gNDA7XG4gICAgICAgIGJvbWJDb2RlLmluaXRCb21iV2l0aCh0aGlzLnBsYXllckNvZGUuaSwgdGhpcy5wbGF5ZXJDb2RlLmosIDApO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlOWVkNFFWdEY5SlRMYys2Q3J2cWxiaycsICdQbGF5ZXInKTtcbi8vIFNjcmlwdHMvUGxheWVyL1BsYXllci5qc1xuXG5cbnZhciBESVJFQ1RJT04gPSBjYy5FbnVtKHtcbiAgICBVUDogMSxcbiAgICBET1dOOiAyLFxuICAgIExFRlQ6IDMsXG4gICAgUklHSFQ6IDRcbn0pO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGRpcmVjdGlvbjogY2MuSW50ZWdlcixcbiAgICAgICAgc3BlZWQ6IDEsXG4gICAgICAgIGk6IDAsXG4gICAgICAgIGo6IDBcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuZGVmWCA9IC0yODI7XG4gICAgICAgIHRoaXMuZGVmWSA9IDM5MDtcbiAgICAgICAgdGhpcy5oZXJvQXRsYXMgPSB7fTtcbiAgICAgICAgdGhpcy53YWxrcyA9IFtbXSwgWzAsIDFdLCBbMCwgLTFdLCBbLTEsIDBdLCBbMSwgMF1dO1xuICAgICAgICB0aGlzLmFjdGlvbiA9IFtcIlwiLCBcImhlcm9fdXBcIiwgXCJoZXJvX2Rvd25cIiwgXCJoZXJvX3JpZ2h0XCIsIFwiaGVyb19sZWZ0XCJdO1xuICAgIH0sXG5cbiAgICAvL+enu+WKqFxuICAgIG1vdmU6IGZ1bmN0aW9uIG1vdmUoaSwgaiwgZGlyZWN0aW9uKSB7XG4gICAgICAgIHRoaXMuaSA9IGk7XG4gICAgICAgIHRoaXMuaiA9IGo7XG4gICAgICAgIHRoaXMubm9kZS54ID0gdGhpcy5kZWZYICsgaSAqIHRoaXMubm9kZS53aWR0aDtcbiAgICAgICAgdGhpcy5ub2RlLnkgPSB0aGlzLmRlZlkgLSBqICogdGhpcy5ub2RlLmhlaWdodDtcbiAgICAgICAgdmFyIGtleSA9IHRoaXMuYWN0aW9uW2RpcmVjdGlvbl07XG4gICAgICAgIHRoaXMucGxheShrZXkpO1xuICAgICAgICB2YXIgd2FsayA9IHRoaXMud2Fsa3NbZGlyZWN0aW9uXTtcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gd2Fsa1swXSAqIHRoaXMubm9kZS53aWR0aDtcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gd2Fsa1sxXSAqIHRoaXMubm9kZS5oZWlnaHQ7XG4gICAgfSxcblxuICAgIC8v5pS+572u54K45by5XG4gICAgcHV0Qm9tYjogZnVuY3Rpb24gcHV0Qm9tYigpIHt9LFxuXG4gICAgLy/ooqvmlLvlh7tcbiAgICBiZUF0dGFjazogZnVuY3Rpb24gYmVBdHRhY2soKSB7fSxcblxuICAgIC8v6aqR5LmY5Z2Q6LW3XG4gICAgcmlkaW5nTW91bnQ6IGZ1bmN0aW9uIHJpZGluZ01vdW50KHR5cGUpIHt9LFxuXG4gICAgLy/kvb/nlKjnianlk4FcbiAgICB1c2VJdGVtOiBmdW5jdGlvbiB1c2VJdGVtKCkge30sXG5cbiAgICAvL+abtOaNouearuiCpFxuICAgIGluaXRQbGF5ZXJXaXRoVXJsOiBmdW5jdGlvbiBpbml0UGxheWVyV2l0aFVybCh1cmwpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIGlmICh1cmwgPT0gdW5kZWZpbmVkIHx8IHVybCA9PSBcIlwiKSB7XG4gICAgICAgICAgICB1cmwgPSBcIkhlcm8vaGVyb0FsdGFzXCI7XG4gICAgICAgIH1cbiAgICAgICAgc2VsZi5hbmltYXRpb24gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuICAgICAgICBzZWxmLmFuaW1hdGlvbi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyh1cmwsIGNjLlNwcml0ZUF0bGFzLCBmdW5jdGlvbiAoZXJyLCBhdGxhcykge1xuICAgICAgICAgICAgc2VsZi5oZXJvQXRsYXMgPSBhdGxhcztcbiAgICAgICAgICAgIF90aGlzLnBsYXkoXCJoZXJvX3VwXCIpO1xuICAgICAgICB9KTtcbiAgICB9LFxuXG4gICAgLy/liJvlu7rku6VrZXnkuLrmiKrngrnnmoTliqjnlLtcbiAgICBjcmVhdGVBbmltYXRpb25DbGlwczogZnVuY3Rpb24gY3JlYXRlQW5pbWF0aW9uQ2xpcHMoa2V5LCBmcmFtZUNvdW50KSB7XG4gICAgICAgIHZhciBmcmFtZSA9IFtdO1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8PSBmcmFtZUNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGtleSk7XG4gICAgICAgICAgICB2YXIgc3ByaXRlRnJhbWUgPSB0aGlzLmhlcm9BdGxhcy5nZXRTcHJpdGVGcmFtZShrZXkgKyBcIl9cIiArIGkpO1xuICAgICAgICAgICAgZnJhbWUucHVzaChzcHJpdGVGcmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNsaXAgPSBjYy5BbmltYXRpb25DbGlwLmNyZWF0ZVdpdGhTcHJpdGVGcmFtZXMoZnJhbWUsIGZyYW1lQ291bnQpO1xuICAgICAgICBjbGlwLm5hbWUgPSBrZXk7XG4gICAgICAgIGNsaXAud3JhcE1vZGUgPSBjYy5XcmFwTW9kZS5Mb29wO1xuICAgICAgICB0aGlzLmFuaW1hdGlvbi5hZGRDbGlwKGNsaXApO1xuICAgIH0sXG5cbiAgICAvL+aSreaUvuebuOW6lOWKqOeUu1xuICAgIHBsYXk6IGZ1bmN0aW9uIHBsYXkoa2V5KSB7XG4gICAgICAgIGlmICghdGhpcy5hbmltYXRpb24uX25hbWVUb1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgIHRoaXMuY3JlYXRlQW5pbWF0aW9uQ2xpcHMoa2V5LCA2KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFuaW1hdGlvbi5wbGF5KGtleSk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzE3NDg2WFZTYlJOanJia1hMWUkyeTNQJywgJ1N0YXJ0R2FtZScpO1xuLy8gU2NyaXB0cy9VSS9TdGFydEdhbWUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7fSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICBzdGFydEdhbWU6IGZ1bmN0aW9uIHN0YXJ0R2FtZSgpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVZpZXdcIik7XG4gICAgfSxcblxuICAgIG9wZW5IZWxwUGFuZWw6IGZ1bmN0aW9uIG9wZW5IZWxwUGFuZWwoKSB7XG4gICAgICAgIHRoaXMuZ2FtZUNvbnRyb2wuc2hvd0hlbHBQYW5lbCgpO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICcwM2U1MHRkM2xGRXlwY3dkVUpkUUlicycsICdUaWxlTGF5ZXInKTtcbi8vIFNjcmlwdHMvTWFwL1RpbGVMYXllci5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcGFzczogY2MuUHJlZmFiXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICBpZiAoIXRoaXMucGFzc05vZGUpIHtcbiAgICAgICAgICAgIHRoaXMucGFzc05vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBhc3MpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucGFzc05vZGUucGFyZW50ID0gdGhpcy5ub2RlO1xuICAgIH0sXG5cbiAgICAvL+WIneWni+WMluWFs+WNoVxuICAgIGluaXRQYXNzOiBmdW5jdGlvbiBpbml0UGFzcyhjdXJyZW50UGFzcykge1xuICAgICAgICBpZiAoIXRoaXMucGFzc05vZGUpIHtcbiAgICAgICAgICAgIHRoaXMucGFzc05vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBhc3MpO1xuICAgICAgICAgICAgdGhpcy5wYXNzTm9kZS5wYXJlbnQgPSB0aGlzLm5vZGU7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHBhc3NDb2RlID0gdGhpcy5wYXNzTm9kZS5nZXRDb21wb25lbnQoXCJQYXNzXCIpO1xuICAgICAgICBwYXNzQ29kZS5pbml0VGl0bGVCeVBhc3MoY3VycmVudFBhc3MsIHRoaXMubm9kZSk7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdkYjIyMVdPZ1V0TjFLM3ZpWHVFVk1GMScsICdUaXBwbGUnKTtcbi8vIFNjcmlwdHMvUGxheWVyL1RpcHBsZS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiXX0=
