var Player = require("Player");
cc.Class({
    "extends": Player,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {}
});