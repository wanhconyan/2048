"use strict";
cc._RFpush(module, '81146JrpU1IoLa75jnqlGXv', 'Mount');
// Scripts/Player/Mount.js

var Player = require("Player");
cc.Class({
    "extends": Player,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {}
});

cc._RFpop();