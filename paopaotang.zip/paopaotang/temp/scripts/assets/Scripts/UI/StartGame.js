"use strict";
cc._RFpush(module, '17486XVSbRNjrbkXLYI2y3P', 'StartGame');
// Scripts/UI/StartGame.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    startGame: function startGame() {
        cc.director.loadScene("GameView");
    },

    openHelpPanel: function openHelpPanel() {
        this.gameControl.showHelpPanel();
    }

});

cc._RFpop();