require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"Base":[function(require,module,exports){
"use strict";
cc._RFpush(module, '7184bfRVkJHD67n1rai9TFy', 'Base');
// Scripts/Snake/Base.js

var Snake = require("Snake");
cc.Class({
    "extends": cc.Component,

    properties: {
        owner: Snake,
        vx: 0,
        vy: 0,
        texture: cc.SpriteFrame,
        speed: 0,
        angle: 0
    },

    //初始化蛇形状
    init: function init(data) {},

    onLoad: function onLoad() {},

    moveTo: function moveTo() {},

    render: function render() {},

    update: function update(t) {
        this.x += this.vx;
        this.y += this.vy;
    }

});

cc._RFpop();
},{"Snake":"Snake"}],"GameControl":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cb5e2bYhO9J16Ksl3BfTd3j', 'GameControl');
// Scripts/Control/GameControl.js

var Nipple = require("Nipple");
cc.Class({
    "extends": cc.Component,

    properties: {
        nipple: Nipple,
        btnAcc: cc.Button,
        snake: cc.Node
    },

    onLoad: function onLoad() {
        var nippleCode = this.nipple.getComponent("Nipple");
        nippleCode.control = this;
    },

    moveTo: function moveTo(angle) {
        var code = this.snake.getComponent("Snake");
        code.moveTo(angle);
    }
});

cc._RFpop();
},{"Nipple":"Nipple"}],"Global":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6a1d8J9Y7NLopSNzYp/YK57', 'Global');
// Scripts/Module/Global.js

var SPEED = 4;
var SPEED_UP = 8;
var TURN_SPEED = 0.08;
module["export"] = {
    SPEED: SPEED,
    SPEED_UP: SPEED_UP,
    TURN_SPEED: TURN_SPEED
};

cc._RFpop();
},{}],"MapNode":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'da26cQtr+VBb4jWssImSwBJ', 'MapNode');
// Scripts/MapNode.js

cc.Class({
    "extends": cc.Component,

    properties: {
        defH: 80,
        defW: 160,
        stageX: 0,
        stageY: 0
    },

    onLoad: function onLoad() {},

    //设置位置
    setPostion: function setPostion(i, j) {
        this.node.x = i * this.defW + this.stageX + this.defW / 2;
        this.node.y = j * this.defH + this.stageY + this.defH / 2;
        console.log(this.node.x, this.node.y);
    },

    show: function show() {
        this.node.active = true;
    },

    hide: function hide() {
        this.node.active = false;
    }

});

cc._RFpop();
},{}],"Map":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'b60afR7imFCPbclpWEwL8mT', 'Map');
// Scripts/Map.js

cc.Class({
    "extends": cc.Component,

    properties: {
        mapNode: cc.Prefab,
        canvas: cc.Node,
        maxCol: 50,
        maxRaw: 100,
        nodeWith: 160,
        nodeHeight: 80
    },

    onLoad: function onLoad() {
        console.log(this.canvas.width, this.canvas.height);
        this.stageWidth = this.canvas.width;
        this.stageHeight = this.canvas.height;
        this.nodes = [];
        this.renderRaw = this.getEven((this.stageWidth / this.nodeWith >> 0) + 1);
        this.renderCol = this.getEven((this.stageHeight / this.nodeHeight >> 0) + 1);
        this.stageX = -this.stageWidth / 2;
        this.stageY = -this.stageHeight / 2;
        for (var i = 0; i < this.renderRaw; i++) {
            for (var j = 0; j < this.renderCol; j++) {
                var mapNode = cc.instantiate(this.mapNode);
                mapNode.parent = this.node;
                var nodeCode = mapNode.getComponent("MapNode");
                nodeCode.stageX = this.stageX;
                nodeCode.stageY = this.stageY;
                this.nodes.push(nodeCode);
                nodeCode.setPostion(i, j);
            }
        }
    },

    //获取一个偶数
    getEven: function getEven(num) {
        return num % 2 === 0 ? num : num + 1;
    },

    //移动到某一位置 渲染地图
    moveTo: function moveTo(x, y) {
        this.node.x = x;
        this.node.y = y;
        var pos = this.getCenter(x, y);
        this.renderMap(pos.x, pos.y);
    },

    //获取中心点坐标
    getCenter: function getCenter(x, y) {
        var posx = x % this.nodeWith;
        var posy = y % this.node.nodeHeight;

        return { x: posx, y: posy };
    },

    //平铺地图个字
    renderMap: function renderMap(raw, col) {
        this.clear();
        var halfRaw = this.renderRaw >> 1;
        var halfCol = this.renderCol >> 1;
        var index = 0;
        for (var i = -halfRaw; i < halfRaw; i++) {
            for (var j = -renderCol; j < renderCol; j++) {
                var offsetx = i + raw;
                var offsety = j + col;
                if (offsetx < -1 || offsetx > this.maxRaw + 1) continue;
                if (offsety < -1 || offsety > this.maxCol + 1) continue;
                this.nodes[index].setPostion(offsetx, offsety);
                index++;
            }
        }
    }
});

cc._RFpop();
},{}],"Nipple":[function(require,module,exports){
"use strict";
cc._RFpush(module, '8f14d8CYvVH0pZN79ueSaG7', 'Nipple');
// Scripts/Nipple.js

cc.Class({
    'extends': cc.Component,

    properties: {
        angle: 0,
        dtAngle: 0, //每帧移动角度 和当前摇杆离中心位置有关
        nipple: cc.Node,
        canvas: cc.Node,
        maxRange: 100,
        lbl: {
            'default': null,
            type: cc.Label
        }
    },

    onLoad: function onLoad() {
        this.canvas.on('touchstart', this.onTouchStart, this);
        this.canvas.on("touchmove", this.onTouchMove, this);
        this.canvas.on('touchend', this.onTouchEnd, this);
        this.canvas.on('touchcancel', this.onTouchEnd, this);
    },

    //touch start
    onTouchStart: function onTouchStart(event) {
        var touches = event.getTouches();
        var touchLoc = touches[0].getLocation();
        var loc = this.node.convertToWorldSpaceAR(cc.Vec2(0, 0));
        var touchRangeX = Math.abs(loc.x - touchLoc.x);
        var touchRangeY = Math.abs(loc.y - touchLoc.y);
        if (touchRangeX > 83 || touchRangeY > 83) return;
        this.ismove = true;
        this.endX = this.startX = this.nipple.x = 0;
        this.endY = this.startY = this.nipple.y = 0;
    },

    //touch move
    onTouchMove: function onTouchMove(event) {
        if (!this.ismove) return;
        this.startX = this.endX;
        this.startY = this.endY;
        var touchs = event.getTouches();
        var touchLoc = touchs[0].getLocation();
        var loc = this.node.convertToNodeSpaceAR(touchLoc);
        var len = Math.sqrt(loc.x * loc.x + loc.y * loc.y);
        var moveToX = loc.x;;
        var moveToY = loc.y;
        if (len >= this.maxRange) {
            moveToX = loc.x * this.maxRange / len;
            moveToY = loc.y * this.maxRange / len;
        };
        this.endX = this.nipple.x = moveToX;
        this.endY = this.nipple.y = moveToY;
        var startAng = Math.atan(this.startX / this.startY);
        if (this.startY === 0 && this.startX === 0) startAng = 0;
        this.angle = Math.atan(this.endY / this.endX);

        this.lbl.string = "x: " + Math.round(this.endX) + "y: " + Math.round(this.endY) + "angle: " + Math.round(this.angle * 180);

        this.control.moveTo(Math.round(this.angle * 180));
    },

    //touchEnd
    onTouchEnd: function onTouchEnd() {
        this.startX = 0;
        this.startY = 0; //不再像目标输出偏移角度
        this.endX = 0;
        this.endY = 0;
        this.easeInPlay();
        this.ismove = false;
    },

    easeInPlay: function easeInPlay() {
        this.nipple.x = 0;
        this.nipple.y = 0;
    }
});

cc._RFpop();
},{}],"Scaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ef3b5AfVNxIRbZzbBvizzAb', 'Scaler');
// Scripts/Scaler.js

cc.Class({
    'extends': cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.node.on('touchstart', this.onTouchStart, this);
        this.node.on('touchend', this.onTouchEnd, this);
        this.node.on('touchcancel', this.onTouchEnd, this);
    },

    onTouchStart: function onTouchStart() {
        this.node.scaleX = this.node.scaleY = 0.9;
    },

    onTouchEnd: function onTouchEnd() {
        this.node.scaleX = this.node.scaleY = 1;
    }

});

cc._RFpop();
},{}],"SnakeHead":[function(require,module,exports){
"use strict";
cc._RFpush(module, '4c0f7wKW/tOMrOr9LHYJ2vA', 'SnakeHead');
// Scripts/Snake/SnakeHead.js

var Base = require("Base");
var Global = require("Global");
cc.Class({
    "extends": Base,

    properties: {},

    onLoad: function onLoad() {
        this.toAngle = 0;
        this.angle = 0;
    },

    moveTo: function moveTo(angle) {
        this.toAngle = angle;
    },

    update: function update(t) {
        if (this.angle != this.toAngle) {
            this.angle += 0.08;
            this.node.rotation = this.angle;
        }
        this.vx = .5 * Math.cos(this.angle);
        this.vy = .5 * Math.sin(this.angle);
        this.node.x += this.vx;
        this.node.y += this.vy;
        console.log(this.node.x, this.node.y);
    }
});

cc._RFpop();
},{"Base":"Base","Global":"Global"}],"Snake":[function(require,module,exports){
"use strict";
cc._RFpush(module, '4fc03t4wuBL44o5H/XHMJjw', 'Snake');
// Scripts/Snake/Snake.js

var Global = require("Global");
cc.Class({
    "extends": cc.Component,
    properties: {
        angle: 0.0,
        snakeHead: cc.Prefab,
        canvas: cc.Node

    },

    onLoad: function onLoad() {
        this.head = cc.instantiate(this.snakeHead);
        this.head.parent = this.canvas;
        this.headCode = this.head.getComponent("SnakeHead");
    },

    moveTo: function moveTo(angle) {
        this.headCode.moveTo(angle);
    },

    update: function update(t) {}

});

cc._RFpop();
},{"Global":"Global"}]},{},["SnakeHead","Snake","Global","Base","Nipple","Map","GameControl","MapNode","Scaler"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL0FwcGxpY2F0aW9ucy9Db2Nvc0NyZWF0b3IuYXBwL0NvbnRlbnRzL1Jlc291cmNlcy9hcHAuYXNhci9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiYXNzZXRzL1NjcmlwdHMvU25ha2UvQmFzZS5qcyIsImFzc2V0cy9TY3JpcHRzL0NvbnRyb2wvR2FtZUNvbnRyb2wuanMiLCJhc3NldHMvU2NyaXB0cy9Nb2R1bGUvR2xvYmFsLmpzIiwiYXNzZXRzL1NjcmlwdHMvTWFwTm9kZS5qcyIsImFzc2V0cy9TY3JpcHRzL01hcC5qcyIsImFzc2V0cy9TY3JpcHRzL05pcHBsZS5qcyIsImFzc2V0cy9TY3JpcHRzL1NjYWxlci5qcyIsImFzc2V0cy9TY3JpcHRzL1NuYWtlL1NuYWtlSGVhZC5qcyIsImFzc2V0cy9TY3JpcHRzL1NuYWtlL1NuYWtlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNzE4NGJmUlZrSkhENjduMXJhaTlURnknLCAnQmFzZScpO1xuLy8gU2NyaXB0cy9TbmFrZS9CYXNlLmpzXG5cbnZhciBTbmFrZSA9IHJlcXVpcmUoXCJTbmFrZVwiKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBvd25lcjogU25ha2UsXG4gICAgICAgIHZ4OiAwLFxuICAgICAgICB2eTogMCxcbiAgICAgICAgdGV4dHVyZTogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHNwZWVkOiAwLFxuICAgICAgICBhbmdsZTogMFxuICAgIH0sXG5cbiAgICAvL+WIneWni+WMluibh+W9oueKtlxuICAgIGluaXQ6IGZ1bmN0aW9uIGluaXQoZGF0YSkge30sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuXG4gICAgbW92ZVRvOiBmdW5jdGlvbiBtb3ZlVG8oKSB7fSxcblxuICAgIHJlbmRlcjogZnVuY3Rpb24gcmVuZGVyKCkge30sXG5cbiAgICB1cGRhdGU6IGZ1bmN0aW9uIHVwZGF0ZSh0KSB7XG4gICAgICAgIHRoaXMueCArPSB0aGlzLnZ4O1xuICAgICAgICB0aGlzLnkgKz0gdGhpcy52eTtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnY2I1ZTJiWWhPOUoxNktzbDNCZlRkM2onLCAnR2FtZUNvbnRyb2wnKTtcbi8vIFNjcmlwdHMvQ29udHJvbC9HYW1lQ29udHJvbC5qc1xuXG52YXIgTmlwcGxlID0gcmVxdWlyZShcIk5pcHBsZVwiKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBuaXBwbGU6IE5pcHBsZSxcbiAgICAgICAgYnRuQWNjOiBjYy5CdXR0b24sXG4gICAgICAgIHNuYWtlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB2YXIgbmlwcGxlQ29kZSA9IHRoaXMubmlwcGxlLmdldENvbXBvbmVudChcIk5pcHBsZVwiKTtcbiAgICAgICAgbmlwcGxlQ29kZS5jb250cm9sID0gdGhpcztcbiAgICB9LFxuXG4gICAgbW92ZVRvOiBmdW5jdGlvbiBtb3ZlVG8oYW5nbGUpIHtcbiAgICAgICAgdmFyIGNvZGUgPSB0aGlzLnNuYWtlLmdldENvbXBvbmVudChcIlNuYWtlXCIpO1xuICAgICAgICBjb2RlLm1vdmVUbyhhbmdsZSk7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc2YTFkOEo5WTdOTG9wU056WXAvWUs1NycsICdHbG9iYWwnKTtcbi8vIFNjcmlwdHMvTW9kdWxlL0dsb2JhbC5qc1xuXG52YXIgU1BFRUQgPSA0O1xudmFyIFNQRUVEX1VQID0gODtcbnZhciBUVVJOX1NQRUVEID0gMC4wODtcbm1vZHVsZVtcImV4cG9ydFwiXSA9IHtcbiAgICBTUEVFRDogU1BFRUQsXG4gICAgU1BFRURfVVA6IFNQRUVEX1VQLFxuICAgIFRVUk5fU1BFRUQ6IFRVUk5fU1BFRURcbn07XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdkYTI2Y1F0citWQmI0aldzc0ltU3dCSicsICdNYXBOb2RlJyk7XG4vLyBTY3JpcHRzL01hcE5vZGUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGRlZkg6IDgwLFxuICAgICAgICBkZWZXOiAxNjAsXG4gICAgICAgIHN0YWdlWDogMCxcbiAgICAgICAgc3RhZ2VZOiAwXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICAvL+iuvue9ruS9jee9rlxuICAgIHNldFBvc3Rpb246IGZ1bmN0aW9uIHNldFBvc3Rpb24oaSwgaikge1xuICAgICAgICB0aGlzLm5vZGUueCA9IGkgKiB0aGlzLmRlZlcgKyB0aGlzLnN0YWdlWCArIHRoaXMuZGVmVyAvIDI7XG4gICAgICAgIHRoaXMubm9kZS55ID0gaiAqIHRoaXMuZGVmSCArIHRoaXMuc3RhZ2VZICsgdGhpcy5kZWZIIC8gMjtcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5ub2RlLngsIHRoaXMubm9kZS55KTtcbiAgICB9LFxuXG4gICAgc2hvdzogZnVuY3Rpb24gc2hvdygpIHtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgfSxcblxuICAgIGhpZGU6IGZ1bmN0aW9uIGhpZGUoKSB7XG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYjYwYWZSN2ltRkNQYmNscFdFd0w4bVQnLCAnTWFwJyk7XG4vLyBTY3JpcHRzL01hcC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgbWFwTm9kZTogY2MuUHJlZmFiLFxuICAgICAgICBjYW52YXM6IGNjLk5vZGUsXG4gICAgICAgIG1heENvbDogNTAsXG4gICAgICAgIG1heFJhdzogMTAwLFxuICAgICAgICBub2RlV2l0aDogMTYwLFxuICAgICAgICBub2RlSGVpZ2h0OiA4MFxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5jYW52YXMud2lkdGgsIHRoaXMuY2FudmFzLmhlaWdodCk7XG4gICAgICAgIHRoaXMuc3RhZ2VXaWR0aCA9IHRoaXMuY2FudmFzLndpZHRoO1xuICAgICAgICB0aGlzLnN0YWdlSGVpZ2h0ID0gdGhpcy5jYW52YXMuaGVpZ2h0O1xuICAgICAgICB0aGlzLm5vZGVzID0gW107XG4gICAgICAgIHRoaXMucmVuZGVyUmF3ID0gdGhpcy5nZXRFdmVuKCh0aGlzLnN0YWdlV2lkdGggLyB0aGlzLm5vZGVXaXRoID4+IDApICsgMSk7XG4gICAgICAgIHRoaXMucmVuZGVyQ29sID0gdGhpcy5nZXRFdmVuKCh0aGlzLnN0YWdlSGVpZ2h0IC8gdGhpcy5ub2RlSGVpZ2h0ID4+IDApICsgMSk7XG4gICAgICAgIHRoaXMuc3RhZ2VYID0gLXRoaXMuc3RhZ2VXaWR0aCAvIDI7XG4gICAgICAgIHRoaXMuc3RhZ2VZID0gLXRoaXMuc3RhZ2VIZWlnaHQgLyAyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMucmVuZGVyUmF3OyBpKyspIHtcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdGhpcy5yZW5kZXJDb2w7IGorKykge1xuICAgICAgICAgICAgICAgIHZhciBtYXBOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYXBOb2RlKTtcbiAgICAgICAgICAgICAgICBtYXBOb2RlLnBhcmVudCA9IHRoaXMubm9kZTtcbiAgICAgICAgICAgICAgICB2YXIgbm9kZUNvZGUgPSBtYXBOb2RlLmdldENvbXBvbmVudChcIk1hcE5vZGVcIik7XG4gICAgICAgICAgICAgICAgbm9kZUNvZGUuc3RhZ2VYID0gdGhpcy5zdGFnZVg7XG4gICAgICAgICAgICAgICAgbm9kZUNvZGUuc3RhZ2VZID0gdGhpcy5zdGFnZVk7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2Rlcy5wdXNoKG5vZGVDb2RlKTtcbiAgICAgICAgICAgICAgICBub2RlQ29kZS5zZXRQb3N0aW9uKGksIGopO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8v6I635Y+W5LiA5Liq5YG25pWwXG4gICAgZ2V0RXZlbjogZnVuY3Rpb24gZ2V0RXZlbihudW0pIHtcbiAgICAgICAgcmV0dXJuIG51bSAlIDIgPT09IDAgPyBudW0gOiBudW0gKyAxO1xuICAgIH0sXG5cbiAgICAvL+enu+WKqOWIsOafkOS4gOS9jee9riDmuLLmn5PlnLDlm75cbiAgICBtb3ZlVG86IGZ1bmN0aW9uIG1vdmVUbyh4LCB5KSB7XG4gICAgICAgIHRoaXMubm9kZS54ID0geDtcbiAgICAgICAgdGhpcy5ub2RlLnkgPSB5O1xuICAgICAgICB2YXIgcG9zID0gdGhpcy5nZXRDZW50ZXIoeCwgeSk7XG4gICAgICAgIHRoaXMucmVuZGVyTWFwKHBvcy54LCBwb3MueSk7XG4gICAgfSxcblxuICAgIC8v6I635Y+W5Lit5b+D54K55Z2Q5qCHXG4gICAgZ2V0Q2VudGVyOiBmdW5jdGlvbiBnZXRDZW50ZXIoeCwgeSkge1xuICAgICAgICB2YXIgcG9zeCA9IHggJSB0aGlzLm5vZGVXaXRoO1xuICAgICAgICB2YXIgcG9zeSA9IHkgJSB0aGlzLm5vZGUubm9kZUhlaWdodDtcblxuICAgICAgICByZXR1cm4geyB4OiBwb3N4LCB5OiBwb3N5IH07XG4gICAgfSxcblxuICAgIC8v5bmz6ZO65Zyw5Zu+5Liq5a2XXG4gICAgcmVuZGVyTWFwOiBmdW5jdGlvbiByZW5kZXJNYXAocmF3LCBjb2wpIHtcbiAgICAgICAgdGhpcy5jbGVhcigpO1xuICAgICAgICB2YXIgaGFsZlJhdyA9IHRoaXMucmVuZGVyUmF3ID4+IDE7XG4gICAgICAgIHZhciBoYWxmQ29sID0gdGhpcy5yZW5kZXJDb2wgPj4gMTtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgZm9yICh2YXIgaSA9IC1oYWxmUmF3OyBpIDwgaGFsZlJhdzsgaSsrKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBqID0gLXJlbmRlckNvbDsgaiA8IHJlbmRlckNvbDsgaisrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG9mZnNldHggPSBpICsgcmF3O1xuICAgICAgICAgICAgICAgIHZhciBvZmZzZXR5ID0gaiArIGNvbDtcbiAgICAgICAgICAgICAgICBpZiAob2Zmc2V0eCA8IC0xIHx8IG9mZnNldHggPiB0aGlzLm1heFJhdyArIDEpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGlmIChvZmZzZXR5IDwgLTEgfHwgb2Zmc2V0eSA+IHRoaXMubWF4Q29sICsgMSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2Rlc1tpbmRleF0uc2V0UG9zdGlvbihvZmZzZXR4LCBvZmZzZXR5KTtcbiAgICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc4ZjE0ZDhDWXZWSDBwWk43OXVlU2FHNycsICdOaXBwbGUnKTtcbi8vIFNjcmlwdHMvTmlwcGxlLmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgYW5nbGU6IDAsXG4gICAgICAgIGR0QW5nbGU6IDAsIC8v5q+P5bin56e75Yqo6KeS5bqmIOWSjOW9k+WJjeaRh+adhuemu+S4reW/g+S9jee9ruacieWFs1xuICAgICAgICBuaXBwbGU6IGNjLk5vZGUsXG4gICAgICAgIGNhbnZhczogY2MuTm9kZSxcbiAgICAgICAgbWF4UmFuZ2U6IDEwMCxcbiAgICAgICAgbGJsOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9XG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmNhbnZhcy5vbigndG91Y2hzdGFydCcsIHRoaXMub25Ub3VjaFN0YXJ0LCB0aGlzKTtcbiAgICAgICAgdGhpcy5jYW52YXMub24oXCJ0b3VjaG1vdmVcIiwgdGhpcy5vblRvdWNoTW92ZSwgdGhpcyk7XG4gICAgICAgIHRoaXMuY2FudmFzLm9uKCd0b3VjaGVuZCcsIHRoaXMub25Ub3VjaEVuZCwgdGhpcyk7XG4gICAgICAgIHRoaXMuY2FudmFzLm9uKCd0b3VjaGNhbmNlbCcsIHRoaXMub25Ub3VjaEVuZCwgdGhpcyk7XG4gICAgfSxcblxuICAgIC8vdG91Y2ggc3RhcnRcbiAgICBvblRvdWNoU3RhcnQ6IGZ1bmN0aW9uIG9uVG91Y2hTdGFydChldmVudCkge1xuICAgICAgICB2YXIgdG91Y2hlcyA9IGV2ZW50LmdldFRvdWNoZXMoKTtcbiAgICAgICAgdmFyIHRvdWNoTG9jID0gdG91Y2hlc1swXS5nZXRMb2NhdGlvbigpO1xuICAgICAgICB2YXIgbG9jID0gdGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy5WZWMyKDAsIDApKTtcbiAgICAgICAgdmFyIHRvdWNoUmFuZ2VYID0gTWF0aC5hYnMobG9jLnggLSB0b3VjaExvYy54KTtcbiAgICAgICAgdmFyIHRvdWNoUmFuZ2VZID0gTWF0aC5hYnMobG9jLnkgLSB0b3VjaExvYy55KTtcbiAgICAgICAgaWYgKHRvdWNoUmFuZ2VYID4gODMgfHwgdG91Y2hSYW5nZVkgPiA4MykgcmV0dXJuO1xuICAgICAgICB0aGlzLmlzbW92ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuZW5kWCA9IHRoaXMuc3RhcnRYID0gdGhpcy5uaXBwbGUueCA9IDA7XG4gICAgICAgIHRoaXMuZW5kWSA9IHRoaXMuc3RhcnRZID0gdGhpcy5uaXBwbGUueSA9IDA7XG4gICAgfSxcblxuICAgIC8vdG91Y2ggbW92ZVxuICAgIG9uVG91Y2hNb3ZlOiBmdW5jdGlvbiBvblRvdWNoTW92ZShldmVudCkge1xuICAgICAgICBpZiAoIXRoaXMuaXNtb3ZlKSByZXR1cm47XG4gICAgICAgIHRoaXMuc3RhcnRYID0gdGhpcy5lbmRYO1xuICAgICAgICB0aGlzLnN0YXJ0WSA9IHRoaXMuZW5kWTtcbiAgICAgICAgdmFyIHRvdWNocyA9IGV2ZW50LmdldFRvdWNoZXMoKTtcbiAgICAgICAgdmFyIHRvdWNoTG9jID0gdG91Y2hzWzBdLmdldExvY2F0aW9uKCk7XG4gICAgICAgIHZhciBsb2MgPSB0aGlzLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIodG91Y2hMb2MpO1xuICAgICAgICB2YXIgbGVuID0gTWF0aC5zcXJ0KGxvYy54ICogbG9jLnggKyBsb2MueSAqIGxvYy55KTtcbiAgICAgICAgdmFyIG1vdmVUb1ggPSBsb2MueDs7XG4gICAgICAgIHZhciBtb3ZlVG9ZID0gbG9jLnk7XG4gICAgICAgIGlmIChsZW4gPj0gdGhpcy5tYXhSYW5nZSkge1xuICAgICAgICAgICAgbW92ZVRvWCA9IGxvYy54ICogdGhpcy5tYXhSYW5nZSAvIGxlbjtcbiAgICAgICAgICAgIG1vdmVUb1kgPSBsb2MueSAqIHRoaXMubWF4UmFuZ2UgLyBsZW47XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZW5kWCA9IHRoaXMubmlwcGxlLnggPSBtb3ZlVG9YO1xuICAgICAgICB0aGlzLmVuZFkgPSB0aGlzLm5pcHBsZS55ID0gbW92ZVRvWTtcbiAgICAgICAgdmFyIHN0YXJ0QW5nID0gTWF0aC5hdGFuKHRoaXMuc3RhcnRYIC8gdGhpcy5zdGFydFkpO1xuICAgICAgICBpZiAodGhpcy5zdGFydFkgPT09IDAgJiYgdGhpcy5zdGFydFggPT09IDApIHN0YXJ0QW5nID0gMDtcbiAgICAgICAgdGhpcy5hbmdsZSA9IE1hdGguYXRhbih0aGlzLmVuZFkgLyB0aGlzLmVuZFgpO1xuXG4gICAgICAgIHRoaXMubGJsLnN0cmluZyA9IFwieDogXCIgKyBNYXRoLnJvdW5kKHRoaXMuZW5kWCkgKyBcInk6IFwiICsgTWF0aC5yb3VuZCh0aGlzLmVuZFkpICsgXCJhbmdsZTogXCIgKyBNYXRoLnJvdW5kKHRoaXMuYW5nbGUgKiAxODApO1xuXG4gICAgICAgIHRoaXMuY29udHJvbC5tb3ZlVG8oTWF0aC5yb3VuZCh0aGlzLmFuZ2xlICogMTgwKSk7XG4gICAgfSxcblxuICAgIC8vdG91Y2hFbmRcbiAgICBvblRvdWNoRW5kOiBmdW5jdGlvbiBvblRvdWNoRW5kKCkge1xuICAgICAgICB0aGlzLnN0YXJ0WCA9IDA7XG4gICAgICAgIHRoaXMuc3RhcnRZID0gMDsgLy/kuI3lho3lg4/nm67moIfovpPlh7rlgY/np7vop5LluqZcbiAgICAgICAgdGhpcy5lbmRYID0gMDtcbiAgICAgICAgdGhpcy5lbmRZID0gMDtcbiAgICAgICAgdGhpcy5lYXNlSW5QbGF5KCk7XG4gICAgICAgIHRoaXMuaXNtb3ZlID0gZmFsc2U7XG4gICAgfSxcblxuICAgIGVhc2VJblBsYXk6IGZ1bmN0aW9uIGVhc2VJblBsYXkoKSB7XG4gICAgICAgIHRoaXMubmlwcGxlLnggPSAwO1xuICAgICAgICB0aGlzLm5pcHBsZS55ID0gMDtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2VmM2I1QWZWTnhJUmJaemJCdml6ekFiJywgJ1NjYWxlcicpO1xuLy8gU2NyaXB0cy9TY2FsZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge30sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaHN0YXJ0JywgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoZW5kJywgdGhpcy5vblRvdWNoRW5kLCB0aGlzKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGNhbmNlbCcsIHRoaXMub25Ub3VjaEVuZCwgdGhpcyk7XG4gICAgfSxcblxuICAgIG9uVG91Y2hTdGFydDogZnVuY3Rpb24gb25Ub3VjaFN0YXJ0KCkge1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVYID0gdGhpcy5ub2RlLnNjYWxlWSA9IDAuOTtcbiAgICB9LFxuXG4gICAgb25Ub3VjaEVuZDogZnVuY3Rpb24gb25Ub3VjaEVuZCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLnNjYWxlWCA9IHRoaXMubm9kZS5zY2FsZVkgPSAxO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc0YzBmN3dLVy90T01yT3I5TEhZSjJ2QScsICdTbmFrZUhlYWQnKTtcbi8vIFNjcmlwdHMvU25ha2UvU25ha2VIZWFkLmpzXG5cbnZhciBCYXNlID0gcmVxdWlyZShcIkJhc2VcIik7XG52YXIgR2xvYmFsID0gcmVxdWlyZShcIkdsb2JhbFwiKTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogQmFzZSxcblxuICAgIHByb3BlcnRpZXM6IHt9LFxuXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMudG9BbmdsZSA9IDA7XG4gICAgICAgIHRoaXMuYW5nbGUgPSAwO1xuICAgIH0sXG5cbiAgICBtb3ZlVG86IGZ1bmN0aW9uIG1vdmVUbyhhbmdsZSkge1xuICAgICAgICB0aGlzLnRvQW5nbGUgPSBhbmdsZTtcbiAgICB9LFxuXG4gICAgdXBkYXRlOiBmdW5jdGlvbiB1cGRhdGUodCkge1xuICAgICAgICBpZiAodGhpcy5hbmdsZSAhPSB0aGlzLnRvQW5nbGUpIHtcbiAgICAgICAgICAgIHRoaXMuYW5nbGUgKz0gMC4wODtcbiAgICAgICAgICAgIHRoaXMubm9kZS5yb3RhdGlvbiA9IHRoaXMuYW5nbGU7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy52eCA9IC41ICogTWF0aC5jb3ModGhpcy5hbmdsZSk7XG4gICAgICAgIHRoaXMudnkgPSAuNSAqIE1hdGguc2luKHRoaXMuYW5nbGUpO1xuICAgICAgICB0aGlzLm5vZGUueCArPSB0aGlzLnZ4O1xuICAgICAgICB0aGlzLm5vZGUueSArPSB0aGlzLnZ5O1xuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLm5vZGUueCwgdGhpcy5ub2RlLnkpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNGZjMDN0NHd1Qkw0NG81SC9YSE1KancnLCAnU25ha2UnKTtcbi8vIFNjcmlwdHMvU25ha2UvU25ha2UuanNcblxudmFyIEdsb2JhbCA9IHJlcXVpcmUoXCJHbG9iYWxcIik7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGFuZ2xlOiAwLjAsXG4gICAgICAgIHNuYWtlSGVhZDogY2MuUHJlZmFiLFxuICAgICAgICBjYW52YXM6IGNjLk5vZGVcblxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5oZWFkID0gY2MuaW5zdGFudGlhdGUodGhpcy5zbmFrZUhlYWQpO1xuICAgICAgICB0aGlzLmhlYWQucGFyZW50ID0gdGhpcy5jYW52YXM7XG4gICAgICAgIHRoaXMuaGVhZENvZGUgPSB0aGlzLmhlYWQuZ2V0Q29tcG9uZW50KFwiU25ha2VIZWFkXCIpO1xuICAgIH0sXG5cbiAgICBtb3ZlVG86IGZ1bmN0aW9uIG1vdmVUbyhhbmdsZSkge1xuICAgICAgICB0aGlzLmhlYWRDb2RlLm1vdmVUbyhhbmdsZSk7XG4gICAgfSxcblxuICAgIHVwZGF0ZTogZnVuY3Rpb24gdXBkYXRlKHQpIHt9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiXX0=
