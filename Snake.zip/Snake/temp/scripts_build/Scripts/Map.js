"use strict";
cc._RFpush(module, 'b60afR7imFCPbclpWEwL8mT', 'Map');
// Scripts/Map.js

cc.Class({
    "extends": cc.Component,

    properties: {
        mapNode: cc.Prefab,
        canvas: cc.Node,
        maxCol: 50,
        maxRaw: 100,
        nodeWith: 160,
        nodeHeight: 80
    },

    onLoad: function onLoad() {
        console.log(this.canvas.width, this.canvas.height);
        this.stageWidth = this.canvas.width;
        this.stageHeight = this.canvas.height;
        this.nodes = [];
        this.renderRaw = this.stageWidth / this.nodeWith;
        this.renderCol = this.stageHeight / this.nodeHeight;
        for (var i = 0; i < this.renderRaw; i++) {
            for (var j = 0; j < this.renderCol; j++) {
                var mapNode = cc.instantiate(this.mapNode);
                mapNode.parent = this.node;
                this.nodes.push(mapNode);
                mapNode.getComponent("MapNode").setPostion(i, j);
            }
        }
    },

    //移动到某一位置 渲染地图
    moveTo: function moveTo(x, y) {
        var pos = this.getCenter(x, y);
        this.renderMap(pos.x, pos.y);
    },

    //获取中心点坐标
    getCenter: function getCenter(x, y) {
        var posx = x % this.nodeWith;
        var posy = y % this.node.nodeHeight;

        return { x: posx, y: posy };
    },

    //平铺地图个字
    renderMap: function renderMap() {}
});

cc._RFpop();