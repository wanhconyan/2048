const Base = require("Base");
const Global = require("Global");
cc.Class({
    extends: Base,

    properties: {
      
    },

  
    onLoad: function () {
        this.toAngle = 0; 
        this.angle = 0 ;
    },

     moveTo:function(angle)
    {       
        this.toAngle = angle ;
    },

    update:function(t)
    {
        if(this.angle != this.toAngle)
        {
            this.angle += 0.08 ;
            this.node.rotation = this.angle ;
        }
        this.vx = .5 * Math.cos(this.angle);
        this.vy = .5 * Math.sin(this.angle);
        this.node.x += this.vx ;
        this.node.y += this.vy ;
        console.log(this.node.x,this.node.y);
    }
});
