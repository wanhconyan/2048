const SPEED = 4 ;
const SPEED_UP =  8 ;
const TURN_SPEED = 0.08 ;
module.export=
{
    SPEED:SPEED,
    SPEED_UP:SPEED_UP,
    TURN_SPEED:TURN_SPEED
}